"""Print defensible lower bounds for a tiny decoder and Qwen2.5-0.5B."""
import math
from .tiny_model import load_spec


def report():
    c = load_spec()
    L, E, F = c['num_hidden_layers'], c['hidden_size'], c['intermediate_size']
    Hkv, D, T, V = c['num_key_value_heads'], c['head_dim'], c['max_positions'], c['vocab_size']
    # tied embedding/head + 4 attention projection matrices + 3 MLP matrices
    dominant_weights = V*E + L*(2*E*E + 2*E*Hkv*D + 3*E*F)
    nvectors = L*2*Hkv*T
    int16_cache_bytes = nvectors*D*2
    int4_cache_bytes = nvectors*(math.ceil(D/2)+c['kv_scale_bytes'])
    print(f'Tiny parameter matrices (without biases/norms): {dominant_weights:,} bytes at INT8')
    print(f'Tiny KV INT16  : {int16_cache_bytes:,} bytes')
    print(f'Tiny KV INT4   : {int4_cache_bytes:,} bytes, including per-vector scale')
    print(f'KV ratio: {int16_cache_bytes / int4_cache_bytes:.4f}x')
    spartan7_50_bram_bytes = 2700*1024//8
    print(f'XC7S50 maximum block-RAM: {spartan7_50_bram_bytes:,} bytes (not all usable by one RAM)')
    print('Qwen 0.49B * 4 bits = 245,000,000 bytes theoretical, without metadata')
    print('External RAM and bandwidth gate required for Qwen; these are NOT measured performance results.')


if __name__ == '__main__':
    report()
