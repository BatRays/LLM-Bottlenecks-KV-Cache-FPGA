"""Bit-exact *primitive* reference for Q8.8 activations, Q1.7 weights, INT4 KV.

Not a complete integer-inference model. The team must implement integer RMSNorm,
RoPE, SiLU, softmax and the full layer in this module during Labs 7-12.
"""
import numpy as np


def saturate16(x):
    return int(min(32767, max(-32768, int(x))))


def matvec_q88_q17(weights, activations):
    w = np.asarray(weights, dtype=np.int64)
    x = np.asarray(activations, dtype=np.int64)
    if w.ndim != 2 or x.shape != (w.shape[1],):
        raise ValueError('Weights must be [rows,cols], activations [cols]')
    if (w < -128).any() or (w > 127).any() or (x < -32768).any() or (x > 32767).any():
        raise ValueError('Out-of-range Q-format input')
    accum = w @ x
    if (accum < -(2**31)).any() or (accum > 2**31-1).any():
        raise OverflowError('Expected int32 accumulator would overflow')
    return np.array([saturate16(int(v) >> 7) for v in accum], dtype=np.int16)


def _trunc_div_signed(num, den):
    if den <= 0:
        raise ValueError('Scale must be positive')
    return (1 if num >= 0 else -1) * (abs(int(num)) // int(den))


def kv_pack_q88(vec):
    """Per-vector power-of-2 Q8.8 scale, trunc-toward-zero INT4 encoding."""
    x = np.asarray(vec, dtype=np.int64)
    if x.ndim != 1 or len(x) % 2 != 0:
        raise ValueError('Require even-dimensional vector')
    if (x < -32768).any() or (x > 32767).any():
        raise ValueError('Input is not signed Q8.8/INT16')
    m = max([abs(int(z)) for z in x], default=0)
    scale = 1
    while 7 * scale < m:
        scale *= 2
    # after scaling, positive values cannot exceed 7; negative -8 saturates normally
    q = [max(-8, min(7, _trunc_div_signed(z, scale))) for z in x]
    b = bytes(((q[i] & 15) | ((q[i+1] & 15) << 4)) for i in range(0, len(q), 2))
    return b, scale


def kv_unpack_q88(data, scale):
    if scale <= 0:
        raise ValueError('Scale must be positive')
    q = []
    for val in data:
        for nib in ((val & 15), (val >> 4)):
            signed = nib - 16 if nib & 8 else nib
            q.append(saturate16(signed * int(scale)))
    return np.array(q, dtype=np.int16)


def demo():
    x = np.array([256,-128], dtype=np.int16)
    w = np.array([[64,64],[-64,64]], dtype=np.int8)
    print('matvec result Q8.8:', matvec_q88_q17(w,x).tolist())
    packed, scale = kv_pack_q88([32,-32,-256,224])
    print('KV packed bytes:', packed.hex(), 'scale Q8.8:', scale,
          'unpacked:', kv_unpack_q88(packed,scale).tolist())


if __name__ == '__main__':
    demo()
