"""Export a trained tiny PyTorch checkpoint to simple hex files for RTL BRAM.

Quantization is teaching Q1.7 for matrices/embedding and Q8.8 for biases/norms.
This is intentionally NOT a calibrated, production-quality PTQ pass.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from .tiny_model import TinyDecoder, load_spec


def quantize(name, array):
    if name.endswith('.weight') and ('norm' not in name):
        frac, dtype, minimum, maximum = 7, np.int8, -128, 127
    else:
        frac, dtype, minimum, maximum = 8, np.int16, -32768, 32767
    q0 = np.rint(np.asarray(array, dtype=np.float32) * (2 ** frac))
    saturated = int(((q0 < minimum) | (q0 > maximum)).sum())
    q = np.clip(q0, minimum, maximum).astype(dtype)
    return q, frac, saturated


def export(checkpoint_path, destination):
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
    spec = checkpoint.get('spec', load_spec())
    model = TinyDecoder(spec).eval()
    model.load_state_dict(checkpoint['state_dict'], strict=True)
    target = Path(destination)
    target.mkdir(parents=True, exist_ok=True)
    records = []
    for name, tensor in model.state_dict().items():
        arr = tensor.cpu().numpy()
        q, frac, saturated = quantize(name, arr)
        if q.ndim == 2:
            flat = q.reshape(-1)  # row-major
        else:
            flat = q.flatten()
        hex_width = 2 if q.dtype == np.int8 else 4
        mask = 0xff if hex_width == 2 else 0xffff
        lines = ''.join(f'{int(v) & mask:0{hex_width}x}\n' for v in flat)
        filename = name.replace('.', '_') + '.mem'
        (target/filename).write_text(lines)
        records.append({'name': name, 'filename': filename,
                        'shape': list(arr.shape), 'fraction_bits': frac,
                        'bits': q.dtype.itemsize * 8, 'order': 'C row-major',
                        'num_elements': flat.size, 'clipped_elements': saturated,
                        'sha256': hashlib.sha256(lines.encode()).hexdigest()})
    manifest = {'model_spec': spec, 'format': 'signed two-complement hex values, one per line',
                'warning': 'Q1.7 toy quantization needs calibration for model quality',
                'tensors': records}
    (target/'manifest.json').write_text(json.dumps(manifest, indent=2))
    print('Exported', len(records), 'arrays to', target)
    print('Saturated elements:', sum(x['clipped_elements'] for x in records))
    print('WARNING: float checkpoint -> Q1.7 weights has not yet been evaluated end-to-end.')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--checkpoint', default='full_fpga/model_checkpoint.pt')
    p.add_argument('--out', default='full_fpga/weights_mem')
    a = p.parse_args()
    export(a.checkpoint, a.out)


if __name__ == '__main__':
    main()
