"""Train a toy, small decoder to emit POS/NEG/NEU then EOS.

This uses synthetic, templated headlines. It is NOT a trading model.
Training runs on CPU/GPU; only inference is meant to move to FPGA RTL.
"""
import argparse
import json
from pathlib import Path

import torch
from torch.nn import functional as F

from .tiny_model import TinyDecoder, encode_prompt, load_spec

TRAIN_TEMPLATES = {
    'POS': ['{t} beat earnings', '{t} raised guidance', '{t} profits surged',
            '{t} announces stronger demand', '{t} improved revenue'],
    'NEG': ['{t} missed earnings', '{t} cut guidance', '{t} profits plunged',
            '{t} announces weaker demand', '{t} reduced revenue'],
    'NEU': ['{t} reported unchanged outlook', '{t} schedules earnings call',
            '{t} appoints board member', '{t} files annual report', '{t} maintained forecast'],
}
EVAL_TEMPLATES = {
    'POS': ['{t} sales are above expectations', '{t} forecasts better profits'],
    'NEG': ['{t} sales are below expectations', '{t} forecasts lower profits'],
    'NEU': ['{t} released quarterly update', '{t} held investor meeting'],
}


def records(split='train'):
    templates = TRAIN_TEMPLATES if split == 'train' else EVAL_TEMPLATES
    tickers = ('AAA','BBB','CCC','DDD') if split == 'train' else ('QQQ','ZZZ')
    result = []
    for cls, tmpls in templates.items():
        for temp in tmpls:
            for ticker in tickers:
                result.append((f'NEWS: {temp.format(t=ticker)}. SIGNAL:', cls))
    return result


def make_batch(spec, examples, device):
    idx = {s: spec['token_ids'][s] for s in ['POS', 'NEG', 'NEU']}
    inputs, prompt_lens, label_ids = [], [], []
    for text, cls in examples:
        ids = encode_prompt(text, spec)
        if len(ids) >= spec['max_positions']:
            raise ValueError('Need room for a label token within max_positions')
        inputs.append(ids + [idx[cls]])
        prompt_lens.append(len(ids))
        label_ids.append(idx[cls])
    max_len = max(map(len, inputs))
    arr = torch.full((len(inputs), max_len), spec['token_ids']['PAD'], dtype=torch.long)
    for i, seq in enumerate(inputs):
        arr[i, :len(seq)] = torch.tensor(seq, dtype=torch.long)
    return (arr.to(device), torch.tensor(prompt_lens, device=device),
            torch.tensor(label_ids, device=device))


def losses(model, batch):
    x, lens, label_ids = batch
    logits = model.forward_full(x)
    row = torch.arange(len(x), device=x.device)
    label_logits = logits[row, lens-1, :]
    eos_logits = logits[row, lens, :]
    label_loss = F.cross_entropy(label_logits, label_ids)
    eos_label = torch.full_like(label_ids, model.spec['token_ids']['EOS'])
    eos_loss = F.cross_entropy(eos_logits, eos_label)
    label_acc = (label_logits.argmax(-1) == label_ids).float().mean().item()
    return label_loss + 0.2*eos_loss, label_acc


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--steps', type=int, default=250)
    p.add_argument('--batch-size', type=int, default=12)
    p.add_argument('--lr', type=float, default=0.001)
    p.add_argument('--output', default='full_fpga/model_checkpoint.pt')
    p.add_argument('--seed', type=int, default=21)
    args = p.parse_args()
    torch.manual_seed(args.seed)
    torch.set_num_threads(2)
    spec = load_spec()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = TinyDecoder(spec).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)
    data = records('train')
    for step in range(args.steps):
        model.train()
        indices = torch.randint(len(data), (args.batch_size,)).tolist()
        examples = [data[i] for i in indices]
        loss, accuracy = losses(model, make_batch(spec, examples, device))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        if step == 0 or (step+1) % 25 == 0 or step+1 == args.steps:
            print(f'step {step+1:4d}: loss={loss.item():.4f}, train_batch_accuracy={accuracy:.3f}')
    model.eval()
    with torch.no_grad():
        eval_rows = records('eval')
        _, heldout_acc = losses(model, make_batch(spec, eval_rows, device))
    print(f'HELD-OUT TEMPLATE accuracy: {heldout_acc:.3f} (synthetic toy task)')
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'state_dict': model.cpu().state_dict(), 'spec': spec,
                'seed': args.seed, 'steps': args.steps,
                'heldout_label_accuracy': heldout_acc}, output)
    output.with_suffix('.json').write_text(json.dumps({
        'seed': args.seed, 'steps': args.steps, 'heldout_accuracy': heldout_acc,
        'note': 'Toy templated synthetic data, not real trading prediction'}, indent=2))
    print('Saved checkpoint:', output)


if __name__ == '__main__':
    main()
