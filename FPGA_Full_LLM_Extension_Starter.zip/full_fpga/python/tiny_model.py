"""Tiny Qwen-like causal transformer with independent full and KV-cached paths.

A functional software reference, NOT a completed RTL implementation.
The host uses this to learn each mathematical operation and export golden tensors.
Do not call the random, untrained model a useful pretrained language model.
"""
import json
import math
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F

SPEC_PATH = Path(__file__).resolve().parents[1] / 'spec' / 'model_spec.json'


def load_spec():
    return json.loads(SPEC_PATH.read_text())


def encode_prompt(text, spec=None):
    spec = spec or load_spec()
    ids = [spec['token_ids']['BOS']] + list(text.encode('utf-8'))
    if len(ids) > spec['max_positions']:
        raise ValueError(f'{len(ids)} input tokens exceed {spec["max_positions"]} cache entries')
    return ids


class RMSNorm(nn.Module):
    def __init__(self, dim, eps):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x):
        return x * torch.rsqrt(x.float().square().mean(dim=-1, keepdim=True) + self.eps).to(x.dtype) * self.weight


def rotate_pairs(x, positions, theta=10000.0):
    """x: [B, H, T, D], positions: [T]. Adjacent even/odd RoPE convention."""
    d = x.shape[-1]
    assert d % 2 == 0
    freq = 1.0 / (theta ** (torch.arange(0, d, 2, device=x.device, dtype=torch.float32) / d))
    angles = positions.to(torch.float32).reshape(-1, 1) * freq.reshape(1, -1)
    cos = torch.cos(angles)[None, None, :, :]
    sin = torch.sin(angles)[None, None, :, :]
    even = x[..., ::2]
    odd = x[..., 1::2]
    y = torch.stack((even * cos - odd * sin, even * sin + odd * cos), dim=-1)
    return y.flatten(-2)


class DecoderLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        e = config['hidden_size']
        hk = config['num_key_value_heads']
        d = config['head_dim']
        f = config['intermediate_size']
        self.hq = config['num_attention_heads']
        self.hkv = hk
        self.d = d
        self.theta = config['rope_theta']
        self.norm1 = RMSNorm(e, config['rms_norm_eps'])
        self.norm2 = RMSNorm(e, config['rms_norm_eps'])
        self.wq = nn.Linear(e, self.hq * d, bias=True)
        self.wk = nn.Linear(e, hk * d, bias=True)
        self.wv = nn.Linear(e, hk * d, bias=True)
        self.wo = nn.Linear(self.hq * d, e, bias=False)
        self.wgate = nn.Linear(e, f, bias=False)
        self.wup = nn.Linear(e, f, bias=False)
        self.wdown = nn.Linear(f, e, bias=False)

    def _projections(self, x):
        b, t, _ = x.shape
        n = self.norm1(x)
        q = self.wq(n).view(b, t, self.hq, self.d).transpose(1, 2)
        k = self.wk(n).view(b, t, self.hkv, self.d).transpose(1, 2)
        v = self.wv(n).view(b, t, self.hkv, self.d).transpose(1, 2)
        return q, k, v

    def _finish(self, x, attn):
        b, _, t, d = attn.shape
        attn = attn.transpose(1, 2).contiguous().reshape(b, t, self.hq * d)
        x = x + self.wo(attn)
        n = self.norm2(x)
        x = x + self.wdown(F.silu(self.wgate(n)) * self.wup(n))
        return x

    def forward_full(self, x):
        b, t, e = x.shape
        q, k, v = self._projections(x)
        positions = torch.arange(t, device=x.device)
        q = rotate_pairs(q, positions, self.theta)
        k = rotate_pairs(k, positions, self.theta)
        k_rep = k.repeat_interleave(self.hq // self.hkv, dim=1)
        v_rep = v.repeat_interleave(self.hq // self.hkv, dim=1)
        scores = (q @ k_rep.transpose(-1, -2)) / math.sqrt(self.d)
        mask = torch.ones((t,t), device=x.device, dtype=torch.bool).triu(diagonal=1)
        scores = scores.masked_fill(mask, float('-inf'))
        probs = F.softmax(scores, dim=-1)
        attn = probs @ v_rep
        return self._finish(x, attn)

    def forward_one(self, x, cache, position):
        # x: [B,1,E], cache: tuple (K,V) with shape [B,Hkv,t,D]
        q, k, v = self._projections(x)
        pos = torch.tensor([position], device=x.device, dtype=torch.long)
        q = rotate_pairs(q, pos, self.theta)
        k = rotate_pairs(k, pos, self.theta)
        if cache is not None:
            past_k, past_v = cache
            if past_k.shape[2] != position:
                raise ValueError(f'Expected {position} cached keys, received {past_k.shape[2]}')
            k = torch.cat((past_k, k), dim=2)
            v = torch.cat((past_v, v), dim=2)
        k_rep = k.repeat_interleave(self.hq // self.hkv, dim=1)
        v_rep = v.repeat_interleave(self.hq // self.hkv, dim=1)
        scores = (q @ k_rep.transpose(-1,-2)) / math.sqrt(self.d)
        probs = F.softmax(scores, dim=-1)
        attn = probs @ v_rep
        return self._finish(x, attn), (k, v)


class TinyDecoder(nn.Module):
    def __init__(self, spec=None):
        super().__init__()
        self.spec = spec or load_spec()
        c = self.spec
        assert c['hidden_size'] == c['num_attention_heads'] * c['head_dim']
        assert c['num_attention_heads'] % c['num_key_value_heads'] == 0
        e = c['hidden_size']
        self.embed = nn.Embedding(c['vocab_size'], e)
        self.layers = nn.ModuleList(DecoderLayer(c) for _ in range(c['num_hidden_layers']))
        self.final_norm = RMSNorm(e, c['rms_norm_eps'])
        # weight tied with the embeddings: no independent LM head matrix
        nn.init.normal_(self.embed.weight, mean=0, std=0.04)

    def forward_full(self, input_ids):
        if input_ids.shape[1] > self.spec['max_positions']:
            raise ValueError('Too many tokens')
        x = self.embed(input_ids)
        for layer in self.layers:
            x = layer.forward_full(x)
        return F.linear(self.final_norm(x), self.embed.weight)

    def forward_one(self, token_ids, caches=None):
        # token_ids: [B] for one absolute position; all cache layers have equal time size
        if caches is None:
            caches = [None] * len(self.layers)
        if len(caches) != len(self.layers):
            raise ValueError('Wrong layer cache count')
        pos = 0 if caches[0] is None else caches[0][0].shape[2]
        if pos >= self.spec['max_positions']:
            raise ValueError('KV cache is full')
        x = self.embed(token_ids).unsqueeze(1)
        next_caches = []
        for layer, cache in zip(self.layers, caches):
            x, new_cache = layer.forward_one(x, cache, pos)
            next_caches.append(new_cache)
        logits = F.linear(self.final_norm(x[:,0,:]), self.embed.weight)
        return logits, next_caches

    @torch.no_grad()
    def prefill(self, ids):
        caches = None
        logits = None
        for tid in ids:
            token = torch.tensor([tid], dtype=torch.long, device=self.embed.weight.device)
            logits, caches = self.forward_one(token, caches)
        return logits, caches

    @torch.no_grad()
    def generate_ids(self, prompt_ids, max_new_tokens=4):
        if len(prompt_ids) + max_new_tokens > self.spec['max_positions'] + 1:
            raise ValueError('Prompt+generation larger than cache')
        logits, caches = self.prefill(prompt_ids)
        result = []
        for step in range(max_new_tokens):
            next_id = int(logits[0].argmax().item())
            result.append(next_id)
            if next_id == self.spec['token_ids']['EOS']:
                break
            if step < max_new_tokens - 1:
                logits, caches = self.forward_one(torch.tensor([next_id], device=logits.device), caches)
        return result


def demo():
    torch.manual_seed(7)
    model = TinyDecoder().eval()
    prompt = encode_prompt('NEWS: AAA beat estimates. SIGNAL:')
    with torch.no_grad():
        full_last = model.forward_full(torch.tensor([prompt]))[:, -1, :]
        cached_last, caches = model.prefill(prompt)
    print('float cached-vs-full max error:', (full_last-cached_last).abs().max().item())
    print('KV shape at layer 0:', tuple(caches[0][0].shape))
    print('Random-weight model token IDs (not meaningful):', model.generate_ids(prompt, 2))


if __name__ == '__main__':
    demo()
