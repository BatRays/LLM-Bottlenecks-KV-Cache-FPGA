"""Produce initial floating-point golden traces with module-output hooks.

Exercises in Labs 6/7 extend this to full per-operator *integer* golden traces.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from .tiny_model import TinyDecoder, encode_prompt, load_spec


def capture(checkpoint, output, prompt):
    spec = load_spec()
    model = TinyDecoder(spec).eval()
    if checkpoint:
        data = torch.load(checkpoint, map_location='cpu', weights_only=True)
        model.load_state_dict(data['state_dict'])
    else:
        torch.manual_seed(7)
        model = TinyDecoder(spec).eval()
    storage = {}
    handles = []
    for name, module in model.named_modules():
        if name and (name.endswith('norm1') or name.endswith('norm2') or
                     name.endswith('wq') or name.endswith('wk') or
                     name.endswith('wv') or name.endswith('wo') or
                     name.endswith('wgate') or name.endswith('wup') or
                     name.endswith('wdown') or name == 'final_norm'):
            def hook(mod, inp, result, key=name):
                storage[key] = result.detach().cpu().numpy()
            handles.append(module.register_forward_hook(hook))
    ids = encode_prompt(prompt, spec)
    with torch.no_grad():
        full = model.forward_full(torch.tensor([ids]))
        last, caches = model.prefill(ids)
    for h in handles:
        h.remove()
    p = Path(output)
    p.parent.mkdir(parents=True, exist_ok=True)
    storage['last_logits'] = last.numpy()
    storage['token_ids'] = np.array(ids, dtype=np.int32)
    storage['kv_layer0_k'] = caches[0][0].numpy()
    storage['kv_layer0_v'] = caches[0][1].numpy()
    np.savez(p.with_suffix('.npz'), **storage)
    meta = {'prompt': prompt, 'ids': ids,
            'max_float_logit_difference_cached_vs_full': float((full[:, -1, :] - last).abs().max()),
            'note': 'Float tensor traces for model operations; NOT bit-exact integer oracle'}
    p.with_suffix('.json').write_text(json.dumps(meta, indent=2))
    print('Saved', p.with_suffix('.npz'), 'and JSON metadata')


def main():
    a = argparse.ArgumentParser()
    a.add_argument('--checkpoint', default=None)
    a.add_argument('--out', default='full_fpga/golden/first_prompt')
    a.add_argument('--prompt', default='NEWS: AAA beat estimates. SIGNAL:')
    args = a.parse_args()
    capture(args.checkpoint, args.out, args.prompt)


if __name__ == '__main__':
    main()
