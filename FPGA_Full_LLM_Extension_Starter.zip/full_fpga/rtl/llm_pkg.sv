// Baseline constants for the upcoming full-FPGA transformer implementation.
// This is an interface specification, not a finished neural inference core.
package llm_pkg;
    parameter int L     = 2;
    parameter int E     = 64;
    parameter int HQ    = 4;
    parameter int HKV   = 2;
    parameter int D     = 16;
    parameter int FF    = 128;
    parameter int TMAX  = 64;
    parameter int VOCAB = 262;

    typedef logic signed [15:0] act_t;    // Q8.8
    typedef logic signed [7:0]  weight_t; // Q1.7
    typedef logic signed [31:0] acc_t;

    parameter int unsigned BOS = 256;
    parameter int unsigned EOS = 257;
    parameter int unsigned PAD = 258;
    parameter int unsigned POS = 259;
    parameter int unsigned NEG = 260;
    parameter int unsigned NEU = 261;
endpackage
