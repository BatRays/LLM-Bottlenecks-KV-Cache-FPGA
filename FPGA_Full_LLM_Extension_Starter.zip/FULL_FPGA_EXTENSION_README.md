# Full-FPGA Transformer Extension Starter (for Labs 4-17)

This **supplements** your existing FPGA KV-Cache project. It does not replace or modify
Labs 0-3 or the original `src/` and `rtl/` files.

## How to install

1. Extract the original `FPGA_KV_Cache_Starter_Project.zip` and open the
   `kv_fpga_project` root folder in PowerShell.
2. Copy this ZIP's `full_fpga/` folder into `kv_fpga_project/` so the path
   becomes `kv_fpga_project/full_fpga/python/tiny_model.py`.
3. Activate the same Python environment from Lab 0 and ensure it includes
   `torch`, `numpy`, and `pytest`.

## Commands from project root

```powershell
python -m full_fpga.python.feasibility
python -m full_fpga.python.tiny_model
python -m full_fpga.python.fixed_oracle
python -m pytest -q full_fpga/tests
python -m full_fpga.python.train_tiny --steps 250
python -m full_fpga.python.export_weights --checkpoint full_fpga/model_checkpoint.pt
python -m full_fpga.python.reference_trace --checkpoint full_fpga/model_checkpoint.pt
```

The model can be tested without training. Its outputs will be meaningless until
trained. The training command teaches a tiny network to classify **synthetic**
financial headline patterns. Its held-out template quality may be poor and is
not a validated financial sentiment model. Model training occurs on CPU/GPU;
this does not weaken the intended **FPGA-only inference** requirement.

## Verified in the supplied development environment

- The five `full_fpga/tests/test_core.py` tests pass.
- Float full-prefix attention and one-token-at-a-time KV-cache processing
  agree to a small numerical tolerance.
- The memory estimator reports dominant INT8 weights: 90,496 bytes;
  INT16 KV: 16,384 bytes; INT4+scale KV: 5,120 bytes.
- The primitive integer matrix vector operation and INT4 pack/unpack
  references run and output the documented examples.
- A short training smoke run, weight export, and floating trace export worked.

## Not implemented yet (these are the labs your team will build)

- Training for general language modeling or production financial quality
- Calibrated INT8 weights or quantization-aware training
- Complete **bit-exact** fixed-point versions of RMSNorm, RoPE, softmax,
  SwiGLU, and all transformer operations
- Stand-alone SystemVerilog modules for those functions and full FPGA top
- BRAM weight/control interfaces, board-specific I/O, DDR and bitstream
- FPGA-compressed-resident cache integrated into full-model hardware
- Full FPGA vs software measurements

**Important:** `reference_trace.py` writes FLOAT tensors and is only a first
trace exporter. An exact integer oracle for full inference still needs to be
built, as specified by Lab 7. `export_weights.py` uses teaching Q1.7 scaling
and may degrade model accuracy; it is not a calibrated trained-integer model.

## Conventions

- All numeric/shape conventions are in `full_fpga/spec/model_spec.json`.
- `full_fpga/rtl/llm_pkg.sv` is the matching starter RTL package.
- Matrix row-major ordering, Q8.8 vs Q1.7, INT4 nibbles and cache layouts
  are defined in the manual. Do not change them independently in subteams.
