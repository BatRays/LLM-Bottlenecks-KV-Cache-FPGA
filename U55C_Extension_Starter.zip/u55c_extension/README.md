# U55C Extension - cluster-specific preparation scaffold

This directory is a **companion to the U55C-specific lab manual**, not a finished FPGA LLM or XRT application.

## First steps (workstation, no U55C needed)

From a terminal at the root of this extension:

```bash
python3 scripts/cache_layout.py --mode report
python3 -m unittest discover -s tests -v
```

Read `docs/first_access.md` before logging into the cluster. On the approved development node, the read-only `scripts/inventory.sh` collects tool information. It does **not** request a U55C, build a bitstream, flash a shell, or use administrator privileges.

The `rtl/kv_addr.sv` and `tb/tb_kv_addr.sv` files are a small **addressing exercise**, not a working HBM interface. The testbench has not been run against the cluster's actual simulator and must be simulated by your team.

Keep your original completed Labs 0-3 unchanged. Retain the original Full-FPGA Extension Starter (`full_fpga/`) for the tiny PyTorch reference, model spec and fixed-point oracle. This U55C extension adds the cluster/HBM-specific exercises and documentation.

## Folder contents

- `scripts/cache_layout.py`: dependency-free logical/physical sizing and cache address oracle.
- `scripts/inventory.sh`: read-only tool/platform inventory for the **approved development node**.
- `tests/test_cache_layout.py`: golden address tests and two cache sizing examples.
- `rtl/kv_addr.sv`: address-generator starter for fixed-size HBM slots.
- `tb/tb_kv_addr.sv`: smoke test of the address-generator RTL.
- `config/connectivity.example.cfg`: explicitly **not ready-to-run** Vitis HBM connectivity example.
- `docs/first_access.md`: cluster onboarding checklist and non-guessed scheduler guidance.
- `docs/protocol_v1.md`: numerical/interface agreement for the team.

The current full-FPGA HDL extension still requires your team to implement attention, HBM controllers, matrix engine, nonlinear functions, sequence scheduler, Vitis RTL kernel wrapper and XRT host application.
