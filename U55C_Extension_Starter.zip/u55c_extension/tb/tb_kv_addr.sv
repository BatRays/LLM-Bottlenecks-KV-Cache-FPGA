`timescale 1ns/1ps
module tb_kv_addr;
    logic [15:0] layer_i, token_i, head_i;
    logic is_value_i, valid_o;
    logic [63:0] address_o;
    kv_addr dut (.*);

    task automatic check(input int l,t,h,input logic v,
                         input logic ok,input logic [63:0] expected);
        layer_i=l; token_i=t; head_i=h; is_value_i=v;
        #1;
        if (valid_o !== ok || (ok && address_o !== expected)) begin
            $display("ERROR l=%0d t=%0d h=%0d v=%0d got valid=%0d addr=%h",l,t,h,v,valid_o,address_o);
            $fatal(1,"address mismatch");
        end
    endtask
    initial begin
        check(0,0,0,0,1,64'h1000_0000);
        check(0,0,1,0,1,64'h1000_0040);
        check(0,1,0,0,1,64'h1000_0080);
        check(1,0,0,0,1,64'h1000_2000);
        check(1,63,1,1,1,64'h1001_3fc0);
        check(2,0,0,0,0,0);
        check(0,64,0,0,0,0);
        check(0,0,2,0,0,0);
        $display("PASS tb_kv_addr");
        $finish;
    end
endmodule
