// Educational address-generator starter for a padded-slot HBM cache.
// This is NOT an HBM AXI controller and does not perform compression.
module kv_addr #(
    parameter int NUM_LAYERS = 2,
    parameter int MAX_TOKENS = 64,
    parameter int NUM_KV_HEADS = 2,
    parameter int SLOT_BYTES = 64,
    parameter logic [63:0] K_BASE = 64'h0000_0000_1000_0000,
    parameter logic [63:0] V_BASE = 64'h0000_0000_1001_0000
) (
    input logic [15:0] layer_i,
    input logic [15:0] token_i,
    input logic [15:0] head_i,
    input logic        is_value_i,
    output logic       valid_o,
    output logic [63:0] address_o
);
    logic [63:0] entry_index;
    always_comb begin
        valid_o = (layer_i < NUM_LAYERS) &&
                  (token_i < MAX_TOKENS) &&
                  (head_i < NUM_KV_HEADS);
        entry_index = ((64'(layer_i) * MAX_TOKENS + 64'(token_i)) * NUM_KV_HEADS + 64'(head_i));
        address_o = 64'h0;
        if (valid_o)
            address_o = (is_value_i ? V_BASE : K_BASE) + entry_index*SLOT_BYTES;
    end
endmodule
