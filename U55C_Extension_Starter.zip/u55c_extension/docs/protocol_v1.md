# Protocol v1 - initial cross-team agreement

Model: `TinyDecoder-2L-64D`, 2 layers, E=64, Hq=4, Hkv=2, D=16, FFN=128, V=262, TMAX=64.

Numeric: Q1.7 signed INT8 weight, Q8.8 signed INT16 activation, signed >=32-bit accumulate with RTL-compatible arithmetic right shift of 7 and saturation. INT4 KV codes -8..7; even component low nibble, odd high nibble. Per-vector scale stored as Q8.8 16-bit integer (not IEEE FP16). All assumptions and rounding must be copied into the Python oracle.

Cache logical entry `(layer,token,kvhead,kind)` occupies `head_dim/2 + scale_bytes = 10` logical bytes for INT4. K/V are distinct address regions. Starter 64-byte padded slot physical address `base(kind) + (((layer*TMAX + token)*Hkv + head)*64)`. This layout proves correctness but **does not provide physical memory savings** compared with 16-bit cache using the same 64-byte slots. A packed layout is required for honest physical compression claims.

Ready/valid: a data source holds VALID and data stable until accepted. Command `start` may be asserted only while idle; `done` pulses on completion and `busy` covers every active processing cycle. Matrix weights are row-major. K is saved after RoPE; V does not receive RoPE. Each layer has its own cache history; no host KV transfer per token.

XRT control model: choose `ap_ctrl_hs` for first kernel and `xrt::kernel` for host. The `ap_ctrl_hs` control register layout is owned by XRT and kernel metadata; do not use an invented custom register layout. AXI4-HBM master must respect bursts, ready/valid, responses, alignment and 4-KiB boundary constraints.
