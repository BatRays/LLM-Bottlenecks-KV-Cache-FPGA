# U55C first-access checklist

The UIUC public HACC user guide specifies a shared development node, Vitis workflows and installed shells. Its status page lists mlCluster workers with U55Cs and access via Kubernetes. **These do not tell us the exact container name, device resource identifier, .xpfm path or user account.** Obtain those details from the administrator.

## Before login

- [ ] Your access request/agreements are complete and you have the actual onboarding instructions.
- [ ] You have a current clone of the working project and the completed Labs 0-3 output artifacts.
- [ ] You have a list of target files to build; no default installation of packages requires root.

## After login - approved development environment

- [ ] Confirm SSH login account and writable home/scratch locations.
- [ ] Run `scripts/inventory.sh` and record the output.
- [ ] Ask which exact `.xpfm` and shell are supported, and run `platforminfo -p "$PLATFORM"` after configuration.
- [ ] Determine whether `xbutil examine` is allowed only on an allocated worker.
- [ ] Learn where to store `.xo`, `.xclbin`, reports and large weights; avoid filling shared home directories.
- [ ] Get a working sample job submission from staff. **Do not invent Kubernetes resource names or scheduler flags.**

## First allocated-U55C run

- [ ] Verify device visibility with approved XRT diagnostic.
- [ ] Run a staff-provided small known-good xclbin/host example.
- [ ] Confirm HBM memory group IDs from actual xclbin connectivity.
- [ ] Check device-to-host transfer of known values and elapsed kernel cycles.
- [ ] Archive shell name, .xclbin SHA-256, tool versions and logs.

## Forbidden assumptions

Do not attempt JTAG, shell flashing, privileged driver changes or device reset without admin instruction. A development VM may not have direct FPGA access, and a build may require a scheduler-allocated worker to execute.
