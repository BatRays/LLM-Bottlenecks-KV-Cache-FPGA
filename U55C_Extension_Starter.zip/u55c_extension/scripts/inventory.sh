#!/usr/bin/env bash
# Read-only inventory; run on the approved HACC development node only.
set -uo pipefail
printf 'Host: '; hostname
printf 'Kernel: '; uname -sr
for p in vivado v++ platforminfo xbutil xrt-smi g++ ; do
  if command -v "$p" >/dev/null 2>&1; then command -v "$p"; else echo "$p: not on PATH"; fi
done
if command -v vivado >/dev/null 2>&1; then vivado -version 2>&1 | head -n 6; fi
if command -v v++ >/dev/null 2>&1; then v++ --version 2>&1 | head -n 8; fi
if [ -n "${PLATFORM:-}" ] && [ -f "${PLATFORM}" ]; then
  echo "Platform path: ${PLATFORM}"
  if command -v platforminfo >/dev/null 2>&1; then platforminfo -p "$PLATFORM" 2>&1 | head -n 90; fi
else
  echo 'PLATFORM is not set to an existing .xpfm; obtain the cluster-installed file path from staff.'
fi
printf '\nThis script did not request a device or modify a shell.\n'
