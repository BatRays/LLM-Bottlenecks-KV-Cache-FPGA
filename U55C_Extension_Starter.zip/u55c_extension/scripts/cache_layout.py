"""Reference KV address and memory-footprint calculations for U55C labs.

No hardware calls; this is an intentionally small, platform-agnostic oracle.
"""
import argparse
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    layers: int = 2
    max_tokens: int = 64
    kv_heads: int = 2
    head_dim: int = 16
    scale_bytes: int = 2
    slot_bytes: int = 64
    k_base: int = 0x1000_0000
    v_base: int = 0x1001_0000

    @property
    def packed_bytes(self) -> int:
        if self.head_dim % 2:
            raise ValueError('head_dim must be even for this first version')
        return self.head_dim // 2

    @property
    def entries_per_kind(self) -> int:
        return self.layers * self.max_tokens * self.kv_heads

    @property
    def entry_bytes(self) -> int:
        return self.packed_bytes + self.scale_bytes


def index(cfg: Config, layer: int, token: int, head: int) -> int:
    if not (0 <= layer < cfg.layers and 0 <= token < cfg.max_tokens and 0 <= head < cfg.kv_heads):
        raise ValueError('out-of-range cache index')
    return ((layer * cfg.max_tokens + token) * cfg.kv_heads + head)


def address(cfg: Config, layer: int, token: int, head: int, kind: str, *, packed: bool = False) -> int:
    base = {'K': cfg.k_base, 'V': cfg.v_base}[kind]
    stride = cfg.entry_bytes if packed else cfg.slot_bytes
    return base + index(cfg, layer, token, head) * stride


def footprint(cfg: Config):
    n = 2 * cfg.entries_per_kind  # K and V, all layers / positions / heads
    int16_logical = n * cfg.head_dim * 2
    int4_logical = n * cfg.entry_bytes
    int16_slot = n * cfg.slot_bytes
    int4_slot = n * cfg.slot_bytes
    return {'vectors': n, 'int16_logical': int16_logical,
            'int4_logical': int4_logical, 'int16_64byte_slots': int16_slot,
            'int4_64byte_slots': int4_slot,
            'ideal_logical_ratio': int16_logical / int4_logical,
            'first_slot_physical_ratio': int16_slot / int4_slot}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=['report','address'], default='report')
    p.add_argument('--layer', type=int, default=0)
    p.add_argument('--token', type=int, default=0)
    p.add_argument('--head', type=int, default=0)
    p.add_argument('--kind', choices=['K','V'], default='K')
    p.add_argument('--packed', action='store_true', help='Ideal tightly-packed address, not simple HBM slot')
    args = p.parse_args()
    c = Config()
    if args.mode == 'report':
        for k,v in footprint(c).items():
            print(f'{k}: {v}')
        print(f'entry_bytes (INT4 payload+scale): {c.entry_bytes}')
    else:
        print(hex(address(c,args.layer,args.token,args.head,args.kind,packed=args.packed)))


if __name__ == '__main__':
    main()
