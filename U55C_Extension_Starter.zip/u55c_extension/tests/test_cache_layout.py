import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from cache_layout import Config, footprint, address, index


class LayoutTests(unittest.TestCase):
    def test_addresses_first_and_last(self):
        c = Config()
        self.assertEqual(address(c, 0, 0, 0, 'K'), 0x1000_0000)
        self.assertEqual(address(c, 0, 0, 1, 'K'), 0x1000_0040)
        self.assertEqual(address(c, 0, 1, 0, 'K'), 0x1000_0080)
        self.assertEqual(address(c, 1, 0, 0, 'K'), 0x1000_2000)
        self.assertEqual(address(c, 1, 63, 1, 'V'), 0x1001_0000 + 255*64)

    def test_packed_layout(self):
        c = Config()
        self.assertEqual(address(c, 0, 0, 1, 'K', packed=True), c.k_base+10)
        self.assertEqual(address(c, 1, 63, 1, 'K', packed=True), c.k_base+255*10)

    def test_bounds(self):
        c = Config()
        for tup in [(2,0,0), (0,64,0), (0,0,2),(-1,0,0)]:
            with self.assertRaises(ValueError): index(c, *tup)

    def test_footprints(self):
        sizes = footprint(Config())
        self.assertEqual(sizes['vectors'], 512)
        self.assertEqual(sizes['int16_logical'], 16384)
        self.assertEqual(sizes['int4_logical'], 5120)
        self.assertEqual(sizes['int16_64byte_slots'], 32768)
        self.assertEqual(sizes['int4_64byte_slots'], 32768)
        self.assertEqual(sizes['ideal_logical_ratio'], 3.2)
        self.assertEqual(sizes['first_slot_physical_ratio'], 1)


if __name__ == '__main__':
    unittest.main()
