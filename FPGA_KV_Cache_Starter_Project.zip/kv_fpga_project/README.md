# FPGA KV-cache compressor: runnable starter project

Read `docs/LAB_MANUAL.md` first. The accompanying PDF is supplied separately.

## What is already implemented?

- An **actual** per-token/per-head, symmetric INT4 Python codec with two signed nibbles per byte and FP16 scale metadata, with passing unit tests.
- Model loading, KV tensor extraction, quantitative loss analysis, and a **quality round-trip** inference experiment for Qwen2.5-0.5B-Instruct.
- Optional benchmarking against the upstream Hugging Face `QuantizedCache` backend (install `optimum-quanto`). This is **not** the custom FPGA implementation.
- A tiny fixed-scale Q8.8-to-INT4 Verilog packer and INT4-to-Q8.8 unpacker with ready/valid flow control and a testbench. This is **not yet** a dynamic-scale KV codec or board-connected IP.
- An offline synthetic financial-post classifier with labeled examples, latency and macro-F1 evaluator. It does **not** trade.

## Installation (Windows PowerShell)

Use Python 3.10+ in a virtual environment. If you have an NVIDIA GPU, install the matching CUDA-enabled PyTorch build using the command recommended at https://pytorch.org/get-started/locally/.

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
python -m src.fpga_vectors
python -m src.01_baseline
python -m src.02_extract_kv
python -m src.06_codec_sweep
python -m src.03_quality_loop
python -m src.04_hf_cache_benchmark --mode dynamic
# Optional after installing optimum-quanto:
python -m pip install optimum-quanto
python -m src.04_hf_cache_benchmark --mode quantized
python -m src.05_signal_demo --mode baseline
python -m src.05_signal_demo --mode roundtrip
python -m src.07_evaluate_signals --mode baseline
python -m src.07_evaluate_signals --mode roundtrip
```

Commands must run from the project root. `src` must remain a directory inside it. The first model run needs internet access for model weights. CPU inference can take time.

## FPGA simulation

Open `rtl/int4_pack.sv` and `rtl/tb_int4_pack.sv` in Vivado Simulator; set `tb_int4_pack` as the simulation top. Expected output is `PASS: 8 Q8.8 inputs -> 4 INT4 bytes; backpressure tested`. Then add `rtl/int4_unpack.sv` and `rtl/tb_int4_roundtrip.sv`, switch simulation top to `tb_int4_roundtrip`, and expect the separate round-trip PASS message.

## Known limits and honesty requirements

1. `src/03_quality_loop.py` immediately decompresses after each forward call. It measures impact on answer quality but **does not save live KV memory**.
2. `src/04_hf_cache_benchmark.py` is a real compressed-storage comparison but uses the **Hugging Face software quantizer**, not your own codec or FPGA.
3. `rtl/int4_pack.sv` is a fully specified, fixed-scale data-path prototype. It assumes even vector length, no framing information, and inputs in signed Q8.8. Dynamic per-head scale selection, decompression, metadata transport, memory banks and bus integration are future milestones.
4. The Python INT4 codec uses `scale = max(abs(x))/7`, rounds to nearest with `torch.round` (ties-to-even), and stores FP16 scales. The RTL core rounds ties away from zero and divides by 32 fixed-point LSB. **They are two different specified algorithms.** The manual explains how to make a bit-exact FPGA implementation of the Python codec in a later lab; do not compare these as if equivalent yet.
5. Model/API compatibility varies with Transformers version. Freeze the exact environment versions when you get a working result and record them in the report.
