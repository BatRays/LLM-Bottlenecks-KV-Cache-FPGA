`timescale 1ns / 1ps
// Inverse of int4_pack's fixed-scale representation.
// One packed byte -> two signed Q8.8 values, low nibble first.
// The lost low-precision information cannot be recovered.
module int4_unpack (
    input logic clk,
    input logic rst,
    input logic s_valid,
    output logic s_ready,
    input logic [7:0] s_data,
    output logic m_valid,
    input logic m_ready,
    output logic signed [15:0] m_data
);
    logic high_pending;
    logic [3:0] high_nibble;

    function automatic logic signed [15:0] expand4(input logic [3:0] nib);
        logic signed [15:0] sx;
        begin
            sx = {{12{nib[3]}}, nib};
            expand4 = sx <<< 5;
        end
    endfunction

    assign s_ready = !high_pending && (!m_valid || m_ready);

    always_ff @(posedge clk) begin
        if (rst) begin
            high_pending <= 1'b0;
            high_nibble <= 4'h0;
            m_valid <= 1'b0;
            m_data <= 16'sd0;
        end else begin
            if (m_valid && m_ready)
                m_valid <= 1'b0;
            if (high_pending && (!m_valid || m_ready)) begin
                m_data <= expand4(high_nibble);
                m_valid <= 1'b1;
                high_pending <= 1'b0;
            end else if (s_valid && s_ready) begin
                m_data <= expand4(s_data[3:0]);
                high_nibble <= s_data[7:4];
                m_valid <= 1'b1;
                high_pending <= 1'b1;
            end
        end
    end
endmodule
