`timescale 1ns / 1ps
module tb_int4_roundtrip;
    logic clk=0;
    always #5 clk=~clk;
    logic rst=1;
    logic s_valid=0,s_ready;
    logic signed [15:0] s_data=0;
    logic p_valid,p_ready;
    logic [7:0] p_data;
    logic o_valid,o_ready=1;
    logic signed [15:0] o_data;

    int4_pack c(.clk(clk),.rst(rst),.s_valid(s_valid),.s_ready(s_ready),
        .s_data(s_data),.m_valid(p_valid),.m_ready(p_ready),.m_data(p_data));
    int4_unpack d(.clk(clk),.rst(rst),.s_valid(p_valid),.s_ready(p_ready),
        .s_data(p_data),.m_valid(o_valid),.m_ready(o_ready),.m_data(o_data));

    logic signed [15:0] inputs [0:7];
    logic signed [15:0] expected [0:7];
    integer sent=0,received=0,cycles=0;
    initial begin
        inputs[0]=0; inputs[1]=32; inputs[2]=-32; inputs[3]=256;
        inputs[4]=-256; inputs[5]=224; inputs[6]=-16; inputs[7]=16;
        expected[0]=0; expected[1]=32; expected[2]=-32; expected[3]=224;
        expected[4]=-256; expected[5]=224; expected[6]=-32; expected[7]=32;
        repeat (3) @(negedge clk);
        rst=0;
        while (received<8 && cycles<150) begin
            @(negedge clk);
            o_ready=(cycles%6 != 2);
            s_valid=(sent<8);
            if (sent<8) s_data=inputs[sent];
            @(posedge clk);
            if (s_valid && s_ready) sent=sent+1;
            if (o_valid && o_ready) begin
                if (o_data !== expected[received])
                    $fatal(1,"round-trip index %0d got %0d expected %0d",received,o_data,expected[received]);
                received=received+1;
            end
            cycles=cycles+1;
        end
        if (received!=8) $fatal(1,"received %0d of 8",received);
        $display("PASS: packed and unpacked 8 values with stalls; loss is expected");
        $finish;
    end
endmodule
