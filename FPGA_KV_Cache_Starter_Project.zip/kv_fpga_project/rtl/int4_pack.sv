`timescale 1ns / 1ps
// Teaching core: fixed-scale quantization of signed Q8.8 values.
// q = saturate(round_away_from_zero(x/32), -8, 7).
// Each 2 accepted inputs produce one byte, low nibble first.
// NOT a complete system AXI IP (no TLAST, metadata, or dynamic scales).
module int4_pack (
    input  logic               clk,
    input  logic               rst,
    input  logic               s_valid,
    output logic               s_ready,
    input  logic signed [15:0] s_data,
    output logic               m_valid,
    input  logic               m_ready,
    output logic [7:0]         m_data
);
    logic have_low;
    logic [3:0] low_nibble;

    function automatic logic [3:0] quant4(input logic signed [15:0] x);
        logic signed [16:0] a, t;
        begin
            a = {x[15], x};
            if (a >= 0)
                t = (a + 17'sd16) >>> 5;
            else
                t = -(((-a) + 17'sd16) >>> 5);
            if (t > 17'sd7) quant4 = 4'h7;
            else if (t < -17'sd8) quant4 = 4'h8;
            else quant4 = t[3:0];
        end
    endfunction

    assign s_ready = (!m_valid || m_ready);

    always_ff @(posedge clk) begin
        if (rst) begin
            have_low <= 1'b0;
            low_nibble <= 4'h0;
            m_valid <= 1'b0;
            m_data <= 8'h00;
        end else begin
            if (m_valid && m_ready)
                m_valid <= 1'b0;
            if (s_valid && s_ready) begin
                if (!have_low) begin
                    low_nibble <= quant4(s_data);
                    have_low <= 1'b1;
                end else begin
                    m_data <= {quant4(s_data), low_nibble};
                    m_valid <= 1'b1;
                    have_low <= 1'b0;
                end
            end
        end
    end
endmodule
