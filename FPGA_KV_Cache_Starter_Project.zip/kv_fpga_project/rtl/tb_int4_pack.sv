`timescale 1ns / 1ps
module tb_int4_pack;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst = 1;
    logic s_valid = 0, s_ready;
    logic signed [15:0] s_data = 0;
    logic m_valid, m_ready = 1;
    logic [7:0] m_data;
    int4_pack dut (.*);

    logic signed [15:0] input_vec [0:7];
    logic [7:0] expected [0:3];
    integer sent, received, cycles;

    initial begin
        input_vec[0] = 0; input_vec[1] = 32;
        input_vec[2] = -32; input_vec[3] = 256;
        input_vec[4] = -256; input_vec[5] = 224;
        input_vec[6] = -16; input_vec[7] = 16;
        expected[0] = 8'h10; expected[1] = 8'h7f;
        expected[2] = 8'h78; expected[3] = 8'h1f;
        sent = 0; received = 0; cycles = 0;
        repeat (3) @(negedge clk);
        rst = 0;
        // Drive inputs on falling edges; sample handshakes at rising edges.
        while (received < 4 && cycles < 100) begin
            @(negedge clk);
            m_ready = (cycles % 5 != 3);
            s_valid = (sent < 8);
            if (sent < 8) s_data = input_vec[sent];
            @(posedge clk);
            if (s_valid && s_ready) sent = sent + 1;
            if (m_valid && m_ready) begin
                if (m_data !== expected[received])
                    $fatal(1, "byte %0d got %h expected %h", received, m_data, expected[received]);
                received = received + 1;
            end
            cycles = cycles + 1;
        end
        if (received != 4 || sent != 8)
            $fatal(1, "Timed out: sent=%0d received=%0d", sent, received);
        $display("PASS: 8 Q8.8 inputs -> 4 INT4 bytes; backpressure tested");
        $finish;
    end
endmodule
