import time
import torch
from src.llm import load_model, make_input


def sync(device):
    if device == "cuda":
        torch.cuda.synchronize()


def main():
    tok, model, device = load_model()
    prompt = "In two sentences, explain why a stock might fall after weak earnings."
    ids = make_input(tok, prompt, device)
    with torch.inference_mode():
        out = model(input_ids=ids, use_cache=True)
        cache = out.past_key_values
        k = cache.layers[0].keys
        v = cache.layers[0].values
        print("device:", device)
        print("tokens in prompt:", ids.shape[1])
        print("layers:", len(cache.layers))
        print("layer 0 K shape:", tuple(k.shape))
        print("layer 0 V shape:", tuple(v.shape))
        print("layer 0 K dtype:", k.dtype)
        sync(device)
        t0 = time.perf_counter()
        result = model.generate(input_ids=ids, max_new_tokens=24, do_sample=False,
                                use_cache=True, pad_token_id=tok.eos_token_id)
        sync(device)
        seconds = time.perf_counter() - t0
    print("answer:", tok.decode(result[0, ids.shape[1]:], skip_special_tokens=True))
    print("prefill+decode seconds:", round(seconds, 3))
    print("new token throughput including prefill:", round((result.shape[-1] - ids.shape[-1]) / seconds, 2), "tokens/s")


if __name__ == "__main__":
    main()
