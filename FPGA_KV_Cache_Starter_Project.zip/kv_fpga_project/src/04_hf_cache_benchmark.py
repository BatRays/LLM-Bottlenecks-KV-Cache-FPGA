"""Compare true resident baseline and Hugging Face quantized caches.

Requires the optional dependency 'optimum-quanto' for the quanto backend.
The HF implementation is a reference baseline, NOT this team's FPGA design.
"""
import argparse
import csv
import os
import time
import torch
import transformers
from src.llm import load_model, make_input


def sync(device):
    if device == "cuda": torch.cuda.synchronize()


def timed_generate(model, tok, ids, device, mode, length):
    kwargs = dict(input_ids=ids, use_cache=True, do_sample=False,
                  max_new_tokens=length, pad_token_id=tok.eos_token_id)
    if mode == "quantized":
        kwargs["cache_implementation"] = "quantized"
        kwargs["cache_config"] = {"backend": "quanto", "nbits": 4,
                                  "q_group_size": 64, "residual_length": 128}
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    sync(device)
    t0 = time.perf_counter()
    with torch.inference_mode():
        result = model.generate(**kwargs)
    sync(device)
    dt = time.perf_counter() - t0
    peak = (torch.cuda.max_memory_allocated() / 2**20) if device == "cuda" else None
    return dt, result, peak


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["dynamic", "quantized"], default="dynamic")
    p.add_argument("--length", type=int, default=64)
    p.add_argument("--repeats", type=int, default=3)
    args = p.parse_args()
    tok, model, device = load_model()
    prompt = "Discuss how an earnings surprise and changing rates can affect an equity valuation. " * 20
    ids = make_input(tok, prompt, device)
    print("mode:", args.mode, "input tokens:", ids.shape[1], "device:", device)
    # Warm-up must match mode, excluded from timing.
    try:
        timed_generate(model, tok, ids, device, args.mode, 3)
        results = [timed_generate(model, tok, ids, device, args.mode, args.length)
                   for _ in range(args.repeats)]
    except (ImportError, ValueError) as exc:
        print("Cache config or backend incompatible:", exc)
        print("Check your installed Transformers version and install optimum-quanto.")
        raise
    out_file = "results/llm_benchmark.csv"
    cols = ["model", "mode", "device", "input_tokens", "output_tokens",
            "seconds_including_prefill", "generated_tps_including_prefill",
            "peak_cuda_MiB_including_weights", "torch_version", "transformers_version"]
    exists = os.path.exists(out_file)
    with open(out_file, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        if not exists: writer.writeheader()
        for dt, out, peak in results:
            generated = out.shape[-1] - ids.shape[-1]
            record = dict(model="Qwen/Qwen2.5-0.5B-Instruct", mode=args.mode,
                          device=device, input_tokens=ids.shape[-1], output_tokens=generated,
                          seconds_including_prefill=dt, generated_tps_including_prefill=generated/dt,
                          peak_cuda_MiB_including_weights=peak,
                          torch_version=torch.__version__,
                          transformers_version=transformers.__version__)
            writer.writerow(record)
            print(f"seconds={dt:.3f}, generated={generated}, generated_tps_including_prefill={generated/dt:.2f}, peak_cuda_MiB={peak}")
    print("Appended reproducible runs to", out_file)
    print("Note: peak_cuda_MiB includes model weights, activations and cache; do not label it KV-only.")


if __name__ == "__main__":
    main()
