"""Shared small-LLM loader. First run downloads weights from Hugging Face."""
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"


def load_model():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32
    tok = AutoTokenizer.from_pretrained(MODEL_ID)
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID, dtype=dtype)
    model.to(device).eval()
    return tok, model, device


def make_input(tok, text, device):
    messages = [{"role": "user", "content": text}]
    if hasattr(tok, "apply_chat_template"):
        ids = tok.apply_chat_template(messages, tokenize=True,
                                      add_generation_prompt=True,
                                      return_tensors="pt")
    else:
        ids = tok(text, return_tensors="pt")["input_ids"]
    return ids.to(device)
