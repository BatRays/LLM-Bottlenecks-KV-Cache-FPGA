import json
import numpy as np
import torch
from src.llm import load_model, make_input
from src.quant import compare_tensor


def main():
    tok, model, device = load_model()
    text = "Summarize the relationship between earnings guidance, interest rates, and stock prices. " * 5
    ids = make_input(tok, text, device)
    with torch.inference_mode():
        output = model(input_ids=ids, use_cache=True)
    cache = output.past_key_values
    report = []
    for i, layer in enumerate(cache.layers):
        for kind, x in (("key", layer.keys), ("value", layer.values)):
            stats = compare_tensor(x)
            report.append({"layer": i, "kind": kind, **stats})
    np.savez_compressed("results/layer0_kv_trace.npz",
                        keys=cache.layers[0].keys.float().cpu().numpy(),
                        values=cache.layers[0].values.float().cpu().numpy())
    with open("results/kv_analysis.json", "w") as f:
        json.dump(report, f, indent=2)
    total_raw = sum(r["original_bytes"] for r in report)
    total_packed = sum(r["compressed_bytes"] for r in report)
    print("prompt tokens:", ids.shape[1])
    print("original cache MiB:", round(total_raw / 2**20, 3))
    print("compressed representation MiB:", round(total_packed / 2**20, 3))
    print("ratio:", round(total_raw / total_packed, 3))
    print("wrote results/layer0_kv_trace.npz and results/kv_analysis.json")


if __name__ == "__main__":
    main()
