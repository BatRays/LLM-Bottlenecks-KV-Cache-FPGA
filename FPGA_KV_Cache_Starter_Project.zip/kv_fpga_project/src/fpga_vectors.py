"""Golden arithmetic for the supplied hardware quantizer.

FPGA interface takes signed Q8.8 x and rounds x/32 LSB toward nearest,
with exact half ties away from zero, then saturates to [-8, 7].
This is a fixed-scale INT4 starter design; NOT the dynamic-scale PyTorch codec.
"""
import random


def quant_q88(x):
    if not -32768 <= x <= 32767:
        raise ValueError("signed 16-bit input required")
    q = (abs(x) + 16) // 32
    if x < 0: q = -q
    return max(-8, min(7, q))


def packed_pairs(samples):
    if len(samples) % 2:
        raise ValueError("The first FPGA engine requires an even number of samples")
    q = [quant_q88(x) for x in samples]
    return [(q[i] & 15) | ((q[i + 1] & 15) << 4)
            for i in range(0, len(q), 2)]


def main():
    samples = [0, 32, -32, 256, -256, 224, -16, 16]
    print("inputs Q8.8:", samples)
    print("expected packed bytes:", [f"{b:02x}" for b in packed_pairs(samples)])
    random.seed(470)
    samples = [random.randint(-384, 384) for _ in range(128)]
    with open("results/input_q88.mem", "w") as f:
        f.write("\n".join(f"{x & 65535:04x}" for x in samples) + "\n")
    with open("results/expected_int4.mem", "w") as f:
        f.write("\n".join(f"{b:02x}" for b in packed_pairs(samples)) + "\n")
    print("wrote results/input_q88.mem and results/expected_int4.mem")


if __name__ == "__main__":
    main()
