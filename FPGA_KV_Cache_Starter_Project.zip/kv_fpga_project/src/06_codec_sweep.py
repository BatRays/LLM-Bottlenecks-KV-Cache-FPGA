"""INT2/INT4/INT8 per-vector quantization experiment on captured model data.

Requires src/02_extract_kv.py first. Outputs CSV and two PNG charts.
"""
import csv
from pathlib import Path
import numpy as np
import torch
import matplotlib.pyplot as plt


def codec(x, bits):
    """Return reconstructed x, representation size, and packed byte tensor."""
    if bits not in (2, 4, 8):
        raise ValueError("bits must be one of 2,4,8")
    n = 8 // bits
    if x.shape[-1] % n:
        raise ValueError("head_dim must be divisible by codes per byte")
    maxi = (1 << (bits-1)) - 1
    mini = -(1 << (bits-1))
    scale = (x.float().abs().amax(-1, keepdim=True).clamp_min(1e-3) / maxi).half()
    q = torch.round(x.float() / scale.float()).clamp(mini, maxi).to(torch.int16)
    codes = q & ((1 << bits) - 1)
    grouped = codes.reshape(*x.shape[:-1], x.shape[-1] // n, n)
    positions = torch.arange(n, device=x.device, dtype=torch.int16) * bits
    packed = torch.sum(grouped << positions, dim=-1).to(torch.uint8)
    # Unpack as the hardware/reader would, not from the original quantized q.
    parts = [(packed.to(torch.int16) >> (i*bits)) & ((1<<bits)-1)
             for i in range(n)]
    raw = torch.stack(parts, dim=-1).reshape(x.shape)
    signed = torch.where(raw >= (1 << (bits-1)), raw - (1 << bits), raw)
    decoded = (signed.float() * scale.float()).to(x.dtype)
    nbytes = packed.numel() + scale.numel()*scale.element_size()
    return decoded, nbytes, packed


def main():
    path = Path("results/layer0_kv_trace.npz")
    if not path.exists():
        raise SystemExit("Run python -m src.02_extract_kv first")
    src = np.load(path)
    rows = []
    for kind in ("keys", "values"):
        # Standardize the reference to FP16 for a fair 16 -> 8/4/2-bit comparison.
        x = torch.from_numpy(src[kind]).half()
        before = x.numel() * x.element_size()
        for bits in (8, 4, 2):
            y, after, _ = codec(x, bits)
            err = x.float() - y.float()
            rows.append({"kind": kind, "bits": bits, "raw_fp16_bytes": before,
                         "stored_bytes_including_scales": after,
                         "ratio": before/after,
                         "mae": err.abs().mean().item(),
                         "rmse": err.square().mean().sqrt().item()})
    with open("results/codec_sweep.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    for field, filename, label in (("mae", "codec_error.png", "Mean absolute error"),
                                   ("ratio", "codec_compression.png", "Compression ratio (x)")):
        plt.figure(figsize=(7,4))
        for kind in ("keys", "values"):
            subset = sorted((r for r in rows if r["kind"] == kind),key=lambda r:r["bits"])
            plt.plot([r["bits"] for r in subset], [r[field] for r in subset], marker="o", label=kind)
        plt.xlabel("Quantization bit width")
        plt.ylabel(label)
        plt.title(f"Qwen layer 0 KV: {label}")
        plt.xticks([2,4,8]); plt.grid(True); plt.legend();plt.tight_layout()
        plt.savefig("results/"+filename,dpi=150);plt.close()
    for row in rows: print(row)
    print("Saved results/codec_sweep.csv and two PNG plots")


if __name__ == "__main__":
    main()
