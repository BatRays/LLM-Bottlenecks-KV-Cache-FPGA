"""Offline-only synthetic financial-post classifier. No live orders or API calls.

Modes: baseline; roundtrip (quality-only custom codec, NOT resident memory
compression); hf_quantized (genuine compressed software cache, not FPGA).
"""
import argparse
import csv
import importlib
import json
import time
import torch
from src.llm import load_model, make_input


def sync(device):
    if device == "cuda": torch.cuda.synchronize()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("baseline", "roundtrip", "hf_quantized"), default="baseline")
    args = ap.parse_args()
    tok, model, device = load_model()
    with open("data/synthetic_posts.csv", newline="", encoding="utf-8") as f:
        posts = list(csv.DictReader(f))
    rows = []
    for event in posts:
        prompt = (
            "You are classifying a synthetic financial post, not recommending a trade. "
            "Reply with exactly one word: POSITIVE, NEGATIVE, or NEUTRAL. "
            "Consider whether the text contains material company news. "
            f"Post: {event['text']}"
        )
        ids = make_input(tok, prompt, device)
        sync(device)
        start = time.perf_counter()
        with torch.inference_mode():
            if args.mode == "roundtrip":
                step_generate = importlib.import_module("src.03_quality_loop").step_generate
                result = step_generate(model, ids, num_new_tokens=8, quantize=True)
            else:
                kwargs = dict(input_ids=ids, max_new_tokens=8, do_sample=False,
                              pad_token_id=tok.eos_token_id)
                if args.mode == "hf_quantized":
                    kwargs.update(cache_implementation="quantized",
                                  cache_config={"backend":"quanto", "nbits":4,
                                                "q_group_size":64,"residual_length":128})
                result = model.generate(**kwargs)
        sync(device)
        latency_ms = (time.perf_counter() - start) * 1000
        answer = tok.decode(result[0, ids.shape[1]:], skip_special_tokens=True).strip().upper()
        label = answer.split()[0].strip('.,:;!"') if answer else ""
        if label not in ("POSITIVE", "NEGATIVE", "NEUTRAL"):
            label = "ABSTAIN"
        rows.append({"event_id": event["event_id"], "timestamp": event["timestamp"],
                     "ticker": event["ticker"], "gold_label": event["gold_label"],
                     "label": label, "signal": {"POSITIVE":1,"NEGATIVE":-1}.get(label,0),
                     "latency_ms": round(latency_ms,2), "raw_model_output": answer,
                     "mode": args.mode})
    path = f"results/signals_{args.mode}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print(json.dumps(rows, indent=2))
    print("Saved", path)
    print("Outputs are unvalidated sentiment proxies, NOT executable trade recommendations.")


if __name__ == "__main__":
    main()
