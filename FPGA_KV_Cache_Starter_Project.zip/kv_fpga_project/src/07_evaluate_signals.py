"""Evaluate offline classification quality from 05_signal_demo output."""
import argparse
import json
import statistics

LABELS = ("POSITIVE", "NEGATIVE", "NEUTRAL")


def evaluate(rows):
    valid = [r for r in rows if r["label"] != "ABSTAIN"]
    coverage = len(valid) / len(rows) if rows else 0
    correct = sum(r["label"] == r["gold_label"] for r in valid)
    accuracy = correct / len(valid) if valid else 0
    f1s = {}
    for label in LABELS:
        tp = sum(r["label"] == r["gold_label"] == label for r in rows)
        fp = sum(r["label"] == label and r["gold_label"] != label for r in rows)
        fn = sum(r["gold_label"] == label and r["label"] != label for r in rows)
        p = tp / (tp+fp) if (tp+fp) else 0
        recall = tp / (tp+fn) if (tp+fn) else 0
        f1s[label] = 2*p*recall/(p+recall) if (p+recall) else 0
    latencies = [float(r["latency_ms"]) for r in rows]
    return {"count": len(rows), "coverage": coverage,
            "accuracy_on_nonabstained": accuracy, "macro_f1_with_abstentions_as_misses": sum(f1s.values())/3,
            "per_class_f1": f1s,
            "median_latency_ms": statistics.median(latencies) if latencies else None}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("baseline", "roundtrip", "hf_quantized"), default="baseline")
    args = ap.parse_args()
    with open(f"results/signals_{args.mode}.json", encoding="utf-8") as f:
        rows = json.load(f)
    print(json.dumps(evaluate(rows), indent=2))
    print("Five synthetic examples are a software smoke test, not statistical evidence.")


if __name__ == "__main__": main()
