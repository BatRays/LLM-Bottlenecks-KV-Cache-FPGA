"""Greedy LLM with an INT4 round-trip applied after every forward.

This tests whether quantization harms output quality. It does NOT keep
compressed KV tensors in RAM and therefore does NOT save live cache memory.
For genuine compressed-resident caching, use HF QuantizedCache or create
and integrate a custom Cache implementation in a later lab.
"""
import time
import torch
from transformers import DynamicCache
from src.llm import load_model, make_input
from src.quant import compress4, decompress4

PROMPTS = [
    "Explain in simple terms what earnings guidance means.",
    "A company reports revenue growth but lower profit margins. Is this always bullish?",
    "Why can positive news still be followed by a lower stock price?",
]


def step_generate(model, ids, num_new_tokens=16, quantize=False):
    cache = DynamicCache()
    sequence = ids.clone()
    new_ids = []
    with torch.inference_mode():
        for step in range(num_new_tokens):
            # Step 0 processes the prompt. Later steps process only the last token.
            current = ids if step == 0 else new_ids[-1].view(1, 1)
            processed_len = ids.shape[1] + step
            mask = torch.ones((1, processed_len), device=ids.device, dtype=torch.long)
            out = model(input_ids=current, attention_mask=mask,
                        past_key_values=cache, use_cache=True)
            cache = out.past_key_values
            if quantize:
                for layer in cache.layers:
                    layer.keys = decompress4(compress4(layer.keys))
                    layer.values = decompress4(compress4(layer.values))
            next_id = out.logits[:, -1, :].argmax(dim=-1)
            new_ids.append(next_id)
            sequence = torch.cat([sequence, next_id[:, None]], dim=1)
    return sequence


def main():
    tok, model, device = load_model()
    matching = 0
    total = 0
    for prompt in PROMPTS:
        ids = make_input(tok, prompt, device)
        t0 = time.perf_counter()
        a = step_generate(model, ids, quantize=False)
        if device == "cuda": torch.cuda.synchronize()
        t1 = time.perf_counter()
        b = step_generate(model, ids, quantize=True)
        if device == "cuda": torch.cuda.synchronize()
        t2 = time.perf_counter()
        aa = a[0, ids.shape[1]:]
        bb = b[0, ids.shape[1]:]
        matches = int((aa == bb).sum().item())
        matching += matches
        total += aa.numel()
        print("\nPROMPT:", prompt)
        print("FP: ", tok.decode(aa, skip_special_tokens=True))
        print("INT4-roundtrip:", tok.decode(bb, skip_special_tokens=True))
        print("same-position greedy tokens:", matches, "/", aa.numel())
        print("seconds (full, roundtrip):", round(t1-t0, 3), round(t2-t1, 3))
    print("\nAggregate exact token agreement:", round(matching/total, 3))
    print("WARNING: round-trip caches here remain full-precision in RAM.")


if __name__ == "__main__":
    main()
