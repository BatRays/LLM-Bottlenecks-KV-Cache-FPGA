"""Educational 4-bit symmetric per-token/per-head KV quantizer.

Input layout: [batch, kv_heads, tokens, head_dim].
INT4 range: [-8, 7]. Scale is max_abs/7 for each vector.
This is a project baseline, NOT a reproduction of KIVI/KVQuant.
"""
from dataclasses import dataclass
import torch


@dataclass
class Packed4:
    data: torch.Tensor      # uint8; two signed nibbles per byte
    scale: torch.Tensor     # float16, [B,H,T,1]
    shape: tuple
    dtype: torch.dtype

    def nbytes(self):
        return self.data.numel() * self.data.element_size() + self.scale.numel() * self.scale.element_size()


def compress4(x):
    if x.ndim != 4:
        raise ValueError("Expected [B,H,T,D]")
    d = x.shape[-1]
    if d % 2:
        raise ValueError("head_dim must be even for this first version")
    xf = x.float()
    # Use exactly the scale that will be stored (float16) in order to make
    # quantization and dequantization agree at the implemented precision.
    scale = (xf.abs().amax(dim=-1, keepdim=True).clamp_min(1e-3) / 7).to(torch.float16)
    q = torch.round(xf / scale.float()).clamp(-8, 7).to(torch.int16)
    nibbles = q.to(torch.uint8) & 15
    packed = nibbles[..., 0::2] | (nibbles[..., 1::2] << 4)
    return Packed4(packed.contiguous(), scale.contiguous(), tuple(x.shape), x.dtype)


def decompress4(p):
    low = (p.data & 15).to(torch.int16)
    high = ((p.data >> 4) & 15).to(torch.int16)
    low = torch.where(low >= 8, low - 16, low)
    high = torch.where(high >= 8, high - 16, high)
    q = torch.stack([low, high], dim=-1).reshape(p.shape)
    return (q.float() * p.scale.float()).to(p.dtype)


def compare_tensor(x):
    p = compress4(x)
    y = decompress4(p)
    bytes_before = x.numel() * x.element_size()
    bytes_after = p.nbytes()
    return {
        "shape": list(x.shape),
        "original_bytes": bytes_before,
        "compressed_bytes": bytes_after,
        "compression_ratio": bytes_before / bytes_after,
        "max_abs_error": (x.float() - y.float()).abs().max().item(),
        "mean_abs_error": (x.float() - y.float()).abs().mean().item(),
        "rmse": ((x.float() - y.float()).square().mean().sqrt()).item(),
    }
