import torch
import pytest
from src.quant import compress4, decompress4, compare_tensor


def test_shapes_and_ranges():
    x = torch.tensor([[[[-1., 0., 0.25, 0.5, 0.75, 1.],
                        [-3., 0., 1., 2., 3., 4.]]]], dtype=torch.float16)
    q = compress4(x)
    assert q.data.shape == (1, 1, 2, 3)
    assert q.scale.shape == (1, 1, 2, 1)
    assert decompress4(q).shape == x.shape
    assert q.nbytes() == 6 + 4
    assert compare_tensor(x)["compression_ratio"] == pytest.approx(24 / 10)


def test_zero_vector():
    x = torch.zeros((1, 2, 3, 64), dtype=torch.float16)
    assert torch.count_nonzero(decompress4(compress4(x))) == 0


def test_error_bounded():
    torch.manual_seed(0)
    x = torch.randn(1, 2, 8, 64).half()
    p = compress4(x)
    y = decompress4(p)
    bound = p.scale.float().amax().item() / 2 + 0.01
    assert (x.float() - y.float()).abs().max().item() <= bound
    assert p.nbytes() < x.numel() * x.element_size()


def test_bad_dimensions():
    with pytest.raises(ValueError):
        compress4(torch.ones(1, 1, 1, 5))
