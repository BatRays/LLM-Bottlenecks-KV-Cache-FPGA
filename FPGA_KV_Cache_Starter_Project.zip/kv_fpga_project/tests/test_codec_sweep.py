import importlib
import torch

codec = importlib.import_module("src.06_codec_sweep").codec


def test_codec_sizes_and_error():
    x = torch.tensor([[[[0., 0.5, -0.5, 1., -1., 0.25, 0.75, -0.75]]]], dtype=torch.float16)
    outputs = {}
    for bits in (2, 4, 8):
        decoded, size, packed = codec(x, bits)
        assert decoded.shape == x.shape
        assert packed.numel() == (x.numel() * bits // 8)
        assert size == packed.numel() + 2
        outputs[bits] = (x.float() - decoded.float()).abs().mean().item()
    assert outputs[8] <= outputs[4] <= outputs[2]


def test_codec_zero():
    x = torch.zeros(2, 3, 4, 64, dtype=torch.float16)
    for bits in (2, 4, 8):
        decoded, _, packed = codec(x, bits)
        assert torch.count_nonzero(decoded) == 0
        assert torch.count_nonzero(packed) == 0
