from src.fpga_vectors import quant_q88, packed_pairs


def test_gold():
    assert packed_pairs([0,32,-32,256,-256,224,-16,16]) == [0x10,0x7f,0x78,0x1f]


def test_rounding_saturation():
    assert quant_q88(16) == 1
    assert quant_q88(-16) == -1
    assert quant_q88(32767) == 7
    assert quant_q88(-32768) == -8
