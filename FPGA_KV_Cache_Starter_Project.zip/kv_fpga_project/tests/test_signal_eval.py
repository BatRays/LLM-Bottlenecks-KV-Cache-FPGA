import importlib
f=importlib.import_module('src.07_evaluate_signals').evaluate


def test_perfect():
    rows=[{'label':a,'gold_label':a,'latency_ms':5} for a in ('POSITIVE','NEGATIVE','NEUTRAL')]
    d=f(rows)
    assert d['macro_f1_with_abstentions_as_misses']==1
    assert d['coverage']==1
    assert d['accuracy_on_nonabstained']==1


def test_abstention():
    rows=[{'label':'ABSTAIN','gold_label':'POSITIVE','latency_ms':10}]
    d=f(rows)
    assert d['coverage']==0
    assert d['accuracy_on_nonabstained']==0
