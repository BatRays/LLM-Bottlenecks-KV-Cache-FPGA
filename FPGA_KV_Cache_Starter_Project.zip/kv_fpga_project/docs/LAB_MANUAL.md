---
title: "FPGA KV-Cache Compression for LLMs"
subtitle: "A guided, ECE 385-style project laboratory | From zero ML background to measured hardware demonstration"
author: "Team project implementation manual"
date: "November 2026"
geometry: margin=0.76in
fontsize: 10pt
colorlinks: true
linkcolor: blue
---

# How to use this manual

**Target audience:** students who know basic SystemVerilog, FSMs, BRAM, clocks, AXI-Lite and Vivado, but have never built an ML system. This document intentionally explains what an operation does **before** giving instructions for implementing it. It is a guided project rather than a research-paper reproduction.

**What you will deliver:** (1) a running small LLM with a conventional KV cache, (2) an analyzed software INT4 KV codec, (3) inference quality measurements with quantization inside the token generation loop, (4) a genuine software compressed-resident cache baseline, (5) a verified FPGA INT4 data path, (6) a board demo and traffic/latency measurements, (7) a fair performance/accuracy comparison, and (8) an optional financial-news classification demo. Never claim that the FPGA accelerated end-to-end LLM inference unless you actually wire it into the inference path and measure the full time.

**Suggested project duration:** twelve weeks, for a team of three or four. Labs 0-7 plus 9 form a credible simulated-FPGA minimum viable project. Lab 8 adds physical board validation; Lab 10 adds the finance application. Lab 11 is a stretch research option.

**Hardware assumption:** any Vivado-capable FPGA with enough BRAM for one or more vectors. A Spartan-7 or Artix-7 teaching board works for the quantizer prototype; a GPU is useful for model benchmarks, but not required for the first software labs. The exact UART, AXI, DMA, and clock wiring depends on your actual board and is deliberately marked as a board-dependent task, rather than presented as universal code.

**Project safety boundary:** The financial application is an offline signal-research demonstration. No real orders, credentials, account access, leveraged strategies or claims of profitable HFT are required. “HFT-related” means a latency-conscious event processing pipeline; a large model on a CPU/GPU generally does not operate in the microsecond latency regime of traditional market-making HFT.

## At-a-glance schedule

| Week | Lab | Main outcome | Exit test |
|:--|:--|:--|:--|
| 1 | 0 | Working Python/PyTorch/Transformers install | Unit tests pass |
| 1-2 | 1 | Explain tokens, transformers, attention | Solve tiny attention example |
| 2 | 2 | Run a causal LLM and inspect KV arrays | Confirm `[B,H,T,D]` |
| 3 | 3 | Calculate memory and extract real KV | Layer 0 trace and JSON report |
| 4 | 4 | Implement an INT4 Python reference | Byte-exact packing tests |
| 5 | 5 | Measure effect on generated answers | Quality comparisons |
| 6 | 6 | Measure genuine software compressed cache | Baseline vs QuantizedCache |
| 7 | 7 | Simulate FPGA quantizer | Self-checking RTL pass |
| 8 | 8 | Add board I/O + timing and resource report | Loopback with verified bytes |
| 9 | 9 | Benchmark everything fairly | Performance table and plots |
| 10 | 10 | Financial-post classification demo | Reproducible offline results |
| 11-12 | 11 | Advanced integration / research extension | Final demo and report |

**Team responsibilities:** Assign one lead to LLM software, one to FPGA/verification, one to benchmarking/evaluation, and (if four people) one to application/integration. Swap reviewers each week; all teammates should independently understand the attention equation and cache memory formula.

# Part I. Concepts from first principles

## Lab 0 - Setup your environment

### 0.1 Understand what runs where

An LLM is a very large collection of numerical operations, especially matrix multiplications. A conventional FPGA board will **not** run a competitive modern generative model simply because it can execute multipliers. Model weights, internal activations and memory bandwidth are the obstacle. For this project, the **host** runs the transformer and the **FPGA** processes a well-defined stream of its numeric KV data. We can benchmark the FPGA block independently before attempting a live host-to-board connection.

### 0.2 Install the software

1. Install Python 3.10+ and, on Windows, create a virtual environment from PowerShell: `py -3.10 -m venv .venv` then `.\.venv\Scripts\Activate.ps1`.
2. From the project directory run `python -m pip install --upgrade pip` and `python -m pip install -r requirements.txt`.
3. Install the correct GPU-enabled PyTorch build from [PyTorch's installer](https://pytorch.org/get-started/locally/) if CUDA is available. CPU-only is fine for small tests. `python -c "import torch; print(torch.__version__, torch.cuda.is_available())"` confirms your backend.
4. Run `python -m pytest -q`; the project should show **10 passed**. Do this before installing ML models: these tests run on synthetic tensors and do not download anything.
5. Run `python -m src.fpga_vectors`. Expect the bytes `10 7f 78 1f` and two files under `results/`.
6. Install Vivado and verify that you can run an ordinary RTL behavioral simulation. **No board is needed yet.**

**Expected artifact:** screenshot or text log showing the Python version, PyTorch version, CUDA availability, test pass, and FPGA simulation tool version.

**Common errors:** `python not recognized` means the interpreter is not on PATH (use the full `python.exe` path); `No module named src` means you are not running commands from the root project directory; `CUDA unavailable` means a CPU-only torch wheel or incompatible driver was installed. The model download requires an internet connection the first time.

### 0.3 Project directory walkthrough

- `src/quant.py`: your Python INT4 numerical specification.
- `src/01_baseline.py`: loads Qwen and inspects its real KV cache.
- `src/02_extract_kv.py`: saves representative key/value data, compares sizes.
- `src/03_quality_loop.py`: inserts INT4 rounding/decompression between decoding steps.
- `src/04_hf_cache_benchmark.py`: benchmarks a **different**, genuine compressed-resident software cache.
- `rtl/int4_pack.sv`: fixed-scale, streaming INT4 quantizer/packer.
- `rtl/tb_int4_pack.sv`: self-checking behavioral testbench with output stalls.
- `rtl/int4_unpack.sv`: streaming fixed-scale INT4-to-Q8.8 decompressor.
- `rtl/tb_int4_roundtrip.sv`: self-checking pack/decompress pipeline test with backpressure.
- `src/06_codec_sweep.py`: tested 2/4/8-bit software sweep and plot generator.
- `src/05_signal_demo.py`: artificial financial events to classification labels.
- `src/07_evaluate_signals.py`: compute coverage, macro-F1 and latency from demo labels.
- `results/`: generated results; do not commit giant traces to Git.

**Exit criterion:** You can explain what each file is supposed to prove, and you have not mixed up the software compressed-cache benchmark with FPGA acceleration.

## Lab 1 - Learn how an LLM works

### 1.1 Tokens are numbers, not words

A language model cannot process a string directly. A **tokenizer** turns text into integer token IDs. Some tokens represent whole words, others subwords, symbols or spaces. For instance, a sentence might become a sequence of 12 integers. The vocabulary maps each token ID to a learned vector; this table is called an **embedding**. The model repeatedly transforms those vectors and assigns scores (logits) to possible next tokens. It converts the scores into probabilities and selects or samples one token, then repeats.

An LLM is **not** continuously reading the entire internet while generating. It runs a fixed numerical network using the prompt and any explicitly supplied context. In this project we run **inference**, not training: we use existing model weights, and optimize the temporary information needed to generate more tokens.

### 1.2 Why the transformer uses attention

Suppose the prompt says, “The company cut its forecast because **it** saw weaker demand.” The model needs a mechanism to connect the word “it” with relevant earlier words. A transformer uses **attention** to compute weighted combinations of token information. Each transformer layer creates three distinct vectors from its input:

- **Query (Q):** What information is the current token seeking?
- **Key (K):** What pattern or information does an earlier token offer?
- **Value (V):** What information should that earlier token contribute if selected?

Q, K, V are **numerical arrays, not English strings**. Each is calculated using a learned weight matrix: `Q = X Wq`, `K = X Wk`, `V = X Wv` (layout conventions vary). For one head the attention equation is:

$$\mathrm{Attention}(Q,K,V)=\mathrm{softmax}\left(\frac{QK^{T}}{\sqrt{d}}+M\right)V$$

Here `d` is head dimension, `M` is the causal mask, and `softmax` turns raw scores into positive weights summing to 1. The causal mask prevents a token from using words that have not been generated yet.

### 1.3 Tiny attention calculation (do this by hand)

For a simple head with dimension `d=1`, choose current query `q=1`, two previous keys `k1=1` and `k2=0`, and values `v1=10`, `v2=20`. The score vector is `[1, 0]`. `softmax([1,0])` is approximately `[0.7311,0.2689]`. The output is `0.7311*10 + 0.2689*20 = 12.689`. The original two values were blended according to how relevant their **keys** were to the **query**.

**Your task:** Calculate the output for q=2, keys `[0,1]`, values `[5,25]`; you should get approximately 22.62 (softmax weights `[0.1192,0.8808]`). If you cannot explain why this is not simply a weighted average chosen beforehand, revisit Q and K: **they compute the weights dynamically**.

### 1.4 A model contains many attention heads and layers

A head is a separate way to attend to information. A **layer** includes attention plus other computations, notably feedforward networks and normalization. Many layers are stacked. New token generation involves passing through all layers; therefore **every layer** has its own K/V cache. The stored keys at layer 0 are **not** interchangeable with the keys at layer 23.

Modern models often use **grouped-query attention (GQA)**. The number of **query heads** can be larger than the number of **key/value heads**. Multiple query heads share one stored KV head. Consequently, the KV memory formula uses `num_key_value_heads`, **not** the number of query heads. A positional technique called **RoPE** changes key and query representations based on token positions; careless cache manipulation can break it. We will compress the **already produced** K and V tensors and will not attempt to modify RoPE logic in the basic labs.

### 1.5 Prefill vs decode

**Prefill:** process the prompt's T tokens and construct the initial KV cache. **Decode:** produce subsequent output tokens one at a time; at each new token, use its query against the prior keys, mix values, and append its own K/V vectors. During long generation, reading the large KV cache can cost significant memory traffic. Cache compression attempts to reduce that traffic and capacity.

**Check your understanding:** (1) Why cache K and V but not a permanent copy of every Q? (2) Why is there one KV cache per layer? (3) When would a 4-bit cached value change the next token? (4) Why could a 4-bit cache be slower than FP16 for a very short prompt? **Answer key** is in Appendix A.

## Lab 2 - Run the first real LLM

Use [Qwen2.5-0.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct), a compact and accessible model with Apache 2.0 licensing. It has 24 layers, 14 query heads, 2 KV heads, hidden size 896, and head dimension `896/14=64`, according to its published configuration. This is a particularly useful model to **see GQA in action**. Do not confuse a small development model with a production-quality trading text model.

Run `python -m src.01_baseline`. The first run downloads model weights. Observe the prompt token count, 24 cache layers, layer-0 `K` and `V` shapes, generated answer, and total time. On a one-example prompt you should see shapes of the form `[1,2,T,64]`, with `T` determined by the tokenizer and chat-template tokens. If you use CPU, cached tensors may be FP32; if CUDA, this project requests FP16.

**Prediction before running:** Which dimension should grow as your prompt gets longer? How many bytes does the first layer need? Multiply all four shape dimensions by the number of bytes per element, then multiply by **two** because K and V are both stored. Finally multiply by 24 layers.

**Deliverable:** a short report containing model ID, package version, device, exact tensor shapes, dtype, prompt length, and full generated response. Do not use a GPU-memory reading as though it represented KV memory alone: model weights occupy much more memory for short prompts.

## Lab 3 - Understand the KV-cache memory bottleneck

### 3.1 The key formula

For a full-attention, uniform-layer model:

$$M_{KV}=2\,B\,L\,H_{KV}\,T\,D\,s$$

Here `B` = batch size, `L` = number of layers, `H_KV` = KV heads per layer, `T` = cached tokens, `D` = elements per KV head, `s` = bytes per element. The factor of 2 counts K **and** V.

For Qwen2.5-0.5B, batch 1, 24 layers, 2 KV heads, dimension 64, FP16 (`s=2`):

| Sequence length | Raw FP16 KV size |
|:--|--:|
| 512 tokens | 6 MiB |
| 2,048 tokens | 24 MiB |
| 4,096 tokens | 48 MiB |
| 8,192 tokens | 96 MiB |
| 16,384 tokens | 192 MiB |

For a batch size of 8, multiply those by 8. These are **analytical payload sizes**, not allocator readings or GPU total memory. When caching a sliding-window architecture, the growth can stop at its window, so inspect the actual model.

### 3.2 Why 4-bit should matter

FP16 = 16 bits per scalar. INT4 = 4 bits per scalar. If 100% of the KV payload were coded in INT4, then its ideal payload compression would be 16/4 = **4x**. But the model needs to know how to interpret those 4-bit numbers. Quantizers usually save a **scale** (and sometimes zero-point, outliers, and a high-precision residual). These are additional bytes. Consequently **actual 4-bit KV compression is less than 4x**, even though the ideal numerical-payload ratio is 4x.

### 3.3 Capture the real vectors

Run `python -m src.02_extract_kv`. The script requests an LLM forward pass, visits all 24 cache layers, and writes `results/kv_analysis.json` and a layer-0 tensor trace. Find `shape`, `max_abs_error`, `mean_abs_error`, and `compression_ratio`. The script reports the ratio of a *hypothetical packed representation* against the actual tensor dtype; it does not change the LLM's live memory allocation.

Use the report to compare K and V separately. Their distributions can differ. You are now looking at the actual numerical data your RTL will eventually process, rather than synthetic examples.

**Checkoff:** Explain why an FPGA implementing 4-bit quantization needs more than a 4-bit output wire: what will receive that compressed stream, where will scale metadata go, and how will attention recover the values?

# Part II. Build your software reference

## Lab 4 - Quantization, packing, and decompression

### 4.1 What quantization means

A floating-point number can store many possible real-number values. A signed 4-bit integer can represent **only 16 integer codes**, from -8 through 7. Quantization is a deliberate approximation: map a number to a low-precision integer **plus a rule for reconstructing it**. One symmetric choice is:

$$s=\max(\max_i |x_i|/7,\epsilon)$$
$$q_i=\mathrm{clip}(\mathrm{round}(x_i/s),-8,7)$$
$$\hat{x}_i=sq_i$$

The rounding introduces error. The smaller the scale, the closer nearby values can be represented; but the scale must be large enough to cover the largest magnitude. The design uses a **separate FP16 scale for each `[batch, KV head, token]` vector** of 64 numbers, rather than one global scale for the entire network.

**Example:** vector `[0.0, 0.5, 1.0, -0.5]`; maximum magnitude 1, so `s=1/7`. Quantized integers are approximately `[0,4,7,-4]`, and decompression produces `[0,0.571,1,-0.571]`. Both approximate values differ from the input; that error propagates into attention.

### 4.2 How packing works at the bit level

A standard memory byte is 8 bits. Two 4-bit numbers can be stored in it. Convert a negative signed nibble to its 4-bit two's-complement representation; place the first in bits `[3:0]`, the second in bits `[7:4]`:

`packed_byte = (q0 & 0xF) | ((q1 & 0xF) << 4)`.

For q0=-1, q1=+2: q0 nibble `F`, q1 nibble `2`, resulting byte `0x2F`. To unpack: low = byte & 15; high = byte >> 4; if nibble >= 8, subtract 16 to interpret it as signed. **Packet byte order matters:** fix low-nibble-first from day one, document it, and make every Python and RTL test use that rule.

### 4.3 The exact software design in this project

Open `src/quant.py` and find `compress4()` and `decompress4()`. Understand every operation:

1. `x.float()` computes the scale in FP32, reducing numerical instability.
2. `amax(dim=-1)` finds max magnitude per 64-element vector.
3. `scale.to(float16)` is **part of the stored representation**. We deliberately quantize using this rounded scale so the encoder and decoder agree.
4. `torch.round()` uses round-to-nearest with ties-to-even. Later RTL must match this if you want exact agreement.
5. `clamp(-8,7)` saturates large values.
6. `& 15` extracts 4-bit two's-complement nibbles and `<< 4` creates packed bytes.
7. Decompression sign-extends nibbles and multiplies by the scale.

Run `python -m pytest -q`. Tests cover packing size, zero vectors, error bounds, and refusal of odd head dimensions in this teaching implementation. Add tests for values exactly halfway between two codes, for negative limits, and for outliers. *Always record the metadata bytes in your compression ratio.*

### 4.4 Calculate metadata overhead yourself

Each vector has D=64 values. One INT4 payload uses `64*4/8=32` bytes. One FP16 scale adds 2 bytes, totaling **34 bytes** per vector. The FP16 original uses `64*2=128` bytes per vector. Thus the actual compression ratio of this simple format is `128/34 = 3.7647x`, a **73.44% storage reduction**. This ignores object/allocator alignment, masks, index tables and any hot residual cache; those would need separate accounting.

If your trace is FP32 on CPU, its original 256 bytes divided by 34 is 7.53x. **Do not advertise that as FP16-to-INT4 performance.** Normalize experiments to the same original representation.

### 4.5 Your experiments

Sweep 8-, 4-, and 2-bit quantization in Python. You will need to extend the starter code for 8 and 2 bits (2-bit packs 4 scalars per byte; 8-bit requires no nibble packing). Run `python -m src.06_codec_sweep` after Lab 3. It sweeps 2/4/8 bits on your captured K/V trace, standardizes the reference tensors to FP16, writes `results/codec_sweep.csv`, and creates `results/codec_error.png` and `results/codec_compression.png`. Inspect its `codec()` function for signed nibble/bit packing and add per-channel grouping as an extension. Generate a plot of compression ratio vs mean absolute error, grouped by K and V. Test global scale, per-layer scale, per-token/head scale, and optionally key per-channel scaling. In the first week, learn from the difference rather than chasing papers' state-of-the-art quality.

**Checkoff:** given input vector and scale, manually list every quantized code, the packed bytes, the decompressed values, and the largest absolute error.

## Lab 5 - Insert quantization into model inference

The crucial question is **not** whether you can compress a saved file: it is whether the next token remains sensible after quantized values are reused by attention. The starter experiment changes the live K/V tensors **after each model forward pass**, to approximate how subsequent steps would see their low-precision counterparts.

Run `python -m src.03_quality_loop`. It loads three prompts, generates with a standard `DynamicCache`, then repeats with `compress4() -> decompress4()` applied to all cached keys and values between token-generation steps. It prints both responses, generation time and exact token-position agreement.

**Important limitation:** this is a **quality-only experiment**. It *temporarily packs* KV tensors and immediately *unpacks them back into full-size tensors* held by the cache. It does **not** reduce model-resident cache bytes, so do not call its result “FPGA speedup” or “actual lower live memory.” Its purpose is to test whether your algorithm is compatible with attention and whether approximation changes model output.

### Quality metrics to collect

- **Exact token agreement:** the fraction of generated token IDs matching at the same position. This is easy but brittle: a single early difference can change all later text.
- **Answer-level label agreement:** for structured financial text, compare `POSITIVE/NEGATIVE/NEUTRAL` predictions with annotated labels. This is often more relevant than exact prose.
- **Cross-entropy/perplexity:** calculate next-token negative log-likelihood on held-out text with teacher forcing, then exponentiate the average. Lower perplexity is better. Use the exact same data and tokenizer between conditions.
- **KL divergence or logit distortion:** compare the uncompressed and compressed next-token probability distributions on the same prefix.
- **Numerical error:** use MAE/RMSE and cosine similarity for K/V arrays to debug arithmetic independently of output text.

**Fairness rule:** use the same model weights, precision, prompt, tokenization, maximum output tokens, random seed, decoding strategy and device. For a first experiment use greedy decoding (`do_sample=False`). Avoid using only two cherry-picked example outputs as your quality conclusion.

## Lab 6 - Establish a real, compressed-resident software baseline

Hugging Face includes a `QuantizedCache` implementation that stores some of the KV cache in a quantized representation. Its `hqq` and `quanto` backends and parameter support can vary by package version. The official cache guide includes examples and warns that quantization can **increase latency** for shorter contexts because quant/dequant work takes time.

1. Run `python -m src.04_hf_cache_benchmark --mode dynamic --length 64 --repeats 3`.
2. Optionally install the documented quantization backend with `python -m pip install optimum-quanto`.
3. Run `python -m src.04_hf_cache_benchmark --mode quantized --length 64 --repeats 3`.
4. Repeat with `length=128` and prompts of different lengths. Record the exact package versions and any unsupported cache-option errors; consult the installed library's cache API rather than blindly modifying the benchmark.
5. The script appends one row per measured run to `results/llm_benchmark.csv` with device, model, package versions, times and memory measurements. Report median wall time and tokens/sec, and *separately* report peak CUDA memory if a GPU exists. CUDA peak allocation contains model weights and intermediate activations; it does not measure cache-only occupancy.

**This baseline is not your own quantizer.** Its purpose is to show what an already integrated **software** compressed KV cache does, and to set a realistic benchmark target. Your custom design must eventually implement quantized **storage**, not merely round-trip quantization.

### Why this experiment is important

There are three independent implementation claims:

1. **Mathematical compression:** can the algorithm approximate K/V with fewer bytes?
2. **Live memory reduction:** are smaller packed buffers actually used for cache residency?
3. **Runtime acceleration:** does the entire LLM run faster under this architecture?

You must demonstrate these separately. It is possible to pass #1, pass #2 and **fail** #3.

# Part III. FPGA hardware

## Lab 7 - Implement the first INT4 FPGA engine

### 7.1 Hardware arithmetic is different from Python floating point

Your Python codec calculates a different scale for every 64-element vector, divides by that scale, rounds (ties to even), and packs. Implementing that whole behavior on a small FPGA in one step would add division, buffering, rounding, metadata and resource questions before you even know whether your stream handshake works. Instead, **first build a fixed-scale teaching engine**, then gradually converge on the full algorithm.

Our RTL's input type is signed 16-bit **Q8.8**. This means a stored integer `x_int` represents the real value `x_real=x_int/256`. We choose a fixed quantization step of 32 integer LSBs, i.e. real step `32/256=0.125`. So the hardware computes:

$$q=\mathrm{sat}_{[-8,7]}\left(\mathrm{round\_away\_from\_zero}(x_{int}/32)\right)$$

and packs pairs into one byte. This makes division by 32 a right shift, so the FPGA does not require a floating-point divider. **This starter algorithm is deliberately not yet bit-equivalent to the dynamic-scale Python codec.** One of your project milestones is making them match.

### 7.2 Interface

| Port | Meaning |
|:--|:--|
| `clk` | synchronous system clock |
| `rst` | synchronous active-high reset |
| `s_valid`, `s_ready` | 16-bit input transfer handshake |
| `s_data[15:0]` | signed Q8.8 scalar input |
| `m_valid`, `m_ready` | packed byte transfer handshake |
| `m_data[7:0]` | packed 2 x INT4 codes |

Input is accepted **only** on a rising edge for which both `s_valid && s_ready` are 1. Output is accepted **only** on a rising edge for which both `m_valid && m_ready` are 1. If `m_valid=1` and `m_ready=0`, the output byte and valid flag must stay unchanged. That is called *backpressure*; it prevents data loss when the consumer is temporarily busy.

A one-bit `have_low` register remembers whether the low nibble is waiting for its partner. The first input fills the low nibble, the second fills the high nibble and asserts output valid. The **first core requires even-length vectors**; when odd-length or multiple interleaved streams are needed, add framing (`tlast`), count and padding rules.

### 7.3 Run the testbench

Add `rtl/int4_pack.sv` and `rtl/tb_int4_pack.sv` to a Vivado project; set the testbench as simulation top, and launch behavioral simulation. For a **second test**, also add `rtl/int4_unpack.sv` and `rtl/tb_int4_roundtrip.sv`, change simulation top to `tb_int4_roundtrip`, and expect `PASS: packed and unpacked 8 values with stalls; loss is expected`. The decompressed output is intentionally approximate because four-bit quantization is lossy. The first self-checking testbench sends eight signed Q8.8 inputs and compares four expected output bytes: `10 7f 78 1f`. It also periodically deasserts `m_ready` to ensure the output does not change while stalled.

The expected cases include positive, negative, zero, saturation at ±large values and ±half-LSB rounding cases. Your waveform should show one output every two accepted input transfers **when there are no output stalls**.

**Do not skip the waveform:** capture `s_valid`, `s_ready`, `s_data`, `have_low`, `m_valid`, `m_ready` and `m_data`. Mark one accepted input, one stalled output and one completed two-scalar packet. If the numerical output fails, verify nibble order, sign extension, signed shifts and rounding. If the output disappears under stall, repair the ready/valid design before doing anything with Vivado IP Integrator.

### 7.4 Mandatory extra verification

After the 8-vector test passes, extend the testbench to read the 128-element `results/input_q88.mem` stimulus and compare against `results/expected_int4.mem` from `python -m src.fpga_vectors`. Add **1000 random samples**, bursts of backpressure, input bubbles, reset in the middle of a packet, and saturation edge cases. Have a second teammate review the scoreboard for race conditions.

**Checkoff:** produce a screenshot with `PASS`, waveform, random-vector count, and a short explanation of how `have_low` implements nibble packing.

## Lab 8 - From simulated RTL to an FPGA board

### 8.1 First hardware experiment: local loopback

Do **not** begin with GPU-to-FPGA streaming. Begin with a small table of signed Q8.8 values held in on-chip BRAM or driven by an FSM. Connect the quantizer output to a second BRAM or a register array; compare those output bytes with the Python oracle. Use an LED or UART message for pass/fail.

A practical block diagram is:

`Test vector BRAM -> feeder FSM -> int4_pack -> result BRAM -> checker -> UART/LED`.

Write a feeder which waits for `s_ready`, supplies one 16-bit sample and asserts `s_valid` until it is accepted. Write a collector which asserts `m_ready` while it can store the result and writes bytes to result memory on `m_valid && m_ready`. Use 128 inputs/64 output bytes at first.

### 8.2 Put the quantizer behind a processor-accessible interface

If you are using a MicroBlaze system, use the **AXI-Lite register or AXI BRAM controller workflow** already familiar from digital systems labs. Map a control/status register bank and input/output memory. A proposed register map (not yet coded) is:

| Offset | Register | Meaning |
|:--|:--|:--|
| `0x00` | CONTROL | bit 0 start; bit 1 clear; writing triggers action |
| `0x04` | STATUS | bit 0 busy; bit 1 done; bit 2 overflow |
| `0x08` | LENGTH | number of 16-bit inputs; even in v1 |
| `0x0C` | INPUT_ADDR | offset in input BRAM |
| `0x10` | OUTPUT_ADDR | offset in output BRAM |
| `0x14` | CYCLES | cycles from first input accepted to last output accepted |

One simple implementation uses a MicroBlaze C program to fill BRAM, trigger the engine, poll for DONE and inspect the packed output. A higher-performance implementation uses AXI4-Stream and DMA to move data between memory and the quantizer, as shown in AMD documentation. **The provided `int4_pack.sv` uses ready/valid signals but is not itself a full AXI4-Stream IP core**: it lacks `TLAST`, packet framing, protocol wrappers and board-specific wiring. Do not claim it can be dropped into AXI DMA unchanged.

### 8.3 Resources and timing

In Vivado synthesis/implementation, record LUTs, flip-flops, BRAMs, DSP48s, Fmax/target frequency, and timing slack. Record the exact part number, clock constraint and Vivado version. A design with no valid clock constraint does not have meaningful timing closure; define a clock using an XDC constraint and inspect report_timing_summary.

Compute approximate isolated throughput: if one 16-bit input is accepted every cycle without stalls at `f` MHz, the input stream moves `2f` MB/s and output bytes appear at `f/2` MB/s. For example, at 100 MHz, 200 MB/s raw input and **50 MB/s packed output**. This is a theoretical no-stall core rate, not a measured board-to-PC result. It also highlights why 4x data reduction does not imply 4x software speed.

### 8.4 Hardware-in-the-loop verification

Move a known trace from `results/layer0_kv_trace.npz` through an agreed integer conversion path, into your board input buffers; read back packed results and compare byte for byte with a matching Python **fixed-scale Q8.8** oracle. Include scales and conversion rules in the trace manifest. The two initial codecs have different round/scale rules and therefore are not directly interchangeable.

**Checkpoint:** the board must produce **all** expected packed bytes, not merely a visually plausible waveform, and your report must include a measured end-to-end transfer latency from host command to verified output.

## Lab 8B - Turn the teaching engine into a real KV codec

This is a **required milestone** if the claim is “FPGA accelerates our own LLM KV-cache quantization,” rather than “FPGA performs fixed-scale INT4 packing.”

You need a formal wire format: per vector, `64` signed 16-bit or floating-point input values; metadata specifying `scale` (for example FP16, or a documented fixed-point representation); 32 packed output bytes; and exact framing. You have two reasonable approaches:

**Approach A (recommended first): host-calculated scales.** On the host, compute each vector's `scale=max(abs(x))/7`, transform values into a fixed-point normalized domain, and send a per-vector reciprocal scale plus 64 values to the FPGA. The FPGA handles integer multiply, round, clamp and bit-pack; the host later reconstructs using transmitted scales. Account for the CPU conversion work and extra bus traffic. This isolates FPGA functionality but may lose end-to-end speed to transfers and pre-processing.

**Approach B (stronger hardware contribution): FPGA-calculated scales.** Buffer 64 values, calculate maximum magnitude using a reduction tree/scan, derive a scale or reciprocal (division approximation, lookup table or iterative arithmetic), quantize, pack and transmit scale plus data. Add a separate decompressor (sign extend, multiply by scale, convert to the model's dtype). Verify overflow, saturation, tie rounding and errors from fixed-point approximation. **Do not call a fixed-scale 4-bit packer a complete dynamic KV compressor.**

Build a bit-exact software specification for the chosen hardware arithmetic (`scale` quantization, exact tie rule, saturation, binary format). Generate 10000 test vectors with seeded Python, compare **every output byte and every decoded value** against RTL, including extreme values. Only after this passes should you attempt model-connected streaming.

### Hardware storage and model integration

If you want actual cache-memory savings inside the model, compressed bytes must reside in the cache and attention must use dequantized values at the correct time. The host-to-board workflow is typically:

`new KV -> compress on FPGA -> store packed bytes in host/board memory -> retrieve packed bytes when needed -> decompress -> attention`.

If the attention kernel still expects FP16 arrays on GPU, you may have to decompress back to GPU memory every step. Sending all historical KV data across a slow USB/UART link for every decoded token is likely to be much slower than pure GPU inference. Therefore, a full runtime improvement may require either high-bandwidth PCIe, compressed-cache-aware GPU attention kernels, or moving parts of attention next to the storage. Treat this as **an architectural problem**, not as a testbench bug.

# Part IV. Benchmarking

## Lab 9 - Design a fair, defensible performance study

The research question is not “does INT4 take fewer bytes?” It is “under which workloads and system interfaces does my design improve storage efficiency without unacceptable degradation?”

### 9.1 Separate the comparison groups

| Label | Actual mechanism | What it proves |
|:--|:--|:--|
| A | Ordinary model + FP16/FP32 `DynamicCache` | Reference output, latency, memory |
| B | Same model + Python quantize/dequantize each decode step | Algorithm-level quality impact, **not** memory savings |
| C | Same model + built-in HF `QuantizedCache` | Real software compressed-cache baseline |
| D | FPGA quantizer on synthetic and recorded KV traces | Verified core throughput, resources, accuracy |
| E | Host-to-board round-trip and compressed storage | Actual link overhead; compare with CPU software codec |
| F | **If implemented**: LLM running with custom FPGA-backed resident cache | End-to-end model outcome; valid FPGA/LLM speed claim |

No performance result from group D alone should be reported as full-LLM speedup. Clearly identify the workload, precision, hardware, memory residency and whether transfer times were counted.

### 9.2 Independent variables

- Precision: reference FP16, INT8, INT4 and (stretch) INT2.
- Context: 128, 512, 2048 and (if hardware permits) 4096 tokens.
- Generated length: 32, 128 and 256 tokens.
- Batch size: 1 and 4 if feasible.
- Vector scaling: fixed, per-token/head, optional per-channel K/per-token V.
- System mode: software-only vs FPGA processing; for FPGA separate core-only and host-to-board.

### 9.3 Metrics, units and interpretation

| Metric | How to obtain | Watch out for |
|:--|:--|:--|
| KV compression ratio (x) | actual reference KV bytes / packed payload **plus metadata** | record metadata, allocator, and residual separately |
| First-token latency (ms) | input accepted to first generated token | includes prefill, not just decode |
| Decode rate (tokens/s) | generated tokens / *decode-only* seconds | distinguish from prefill+decode rate |
| End-to-end post-to-label latency (ms) | event arrival through completed classification | include tokenizer, I/O and model |
| FPGA kernel throughput (MB/s) | accepted bytes / measured core elapsed seconds | input vs packed-output basis |
| Transfer bandwidth (MB/s) | bytes / host-to-board elapsed seconds | UART may dominate |
| Error (MAE/RMSE) | compare KV to reconstructed KV | do both K and V, layers |
| Quality (accuracy, F1, perplexity) | held-out labeled prompts/text | distinguish model errors vs compression errors |
| Power (W), energy/event (J) | on-board sensor or external meter if available | report measurement method |
| Resource/timing | LUT, FF, BRAM, DSP, Fmax, WNS | attach clock constraint and reports |

Use CUDA synchronization before and after timed GPU inference. Warm up each mode at least once; then take 5-10 trials and report **median plus range or p95**. Avoid background downloads or other workloads. Fix the model version, seed, tokenization and prompt set. Store raw per-run CSVs, not just one nice chart. For CPU tests report architecture and CPU-only float precision; do not compare those directly to a different GPU machine as if cache compression were the only variable.

### 9.4 Traffic analysis helps explain success or failure

For ordinary autoregressive decode, a naive implementation may read much of the previously stored K/V at each step. Compressed storage decreases the bytes that must be transferred **if** they stay compressed over the bandwidth-limited part of the path. But FPGA compute, metadata, dequantization, packet overhead and host-board bandwidth may cancel the advantage.

Write down the approximate time budget:

`T_total = T_tokenize + T_prefill + N*T_decode + T_transfer + T_FPGA + T_sync + T_application`.

This is a bookkeeping model; some stages may overlap. If you measure `T_FPGA=5 microseconds` but `T_transfer=20 milliseconds`, the 5-microsecond number is not an end-to-end win. Compare to a *software baseline performing the identical quantizer*, not just uncompressed model inference.

### 9.5 Final plots (required)

Prepare **four** plots: (1) KV bytes vs prompt length for baseline/codec; (2) reconstruction error vs quantization bit-width; (3) end-to-end inference latency vs context length for comparably implemented modes; and (4) FPGA achieved MB/s vs theoretical MB/s, with host-link overhead shown separately. A fifth plot of accuracy/F1 vs precision is recommended for the financial demo.

# Part V. Finance application (optional but educational)

## Lab 10 - From financial text to a structured event signal

### 10.1 Why this is not the same as real HFT

Traditional high-frequency trading systems often rely on very low-level market data, specialized network links, exchange colocation and microsecond-scale software/hardware paths. A general-purpose LLM on a laptop/GPU may need **milliseconds to seconds** to produce a text classification, depending on model, device and load. Your prototype is much more accurately described as **latency-aware financial event classification**. It can still be an excellent HFT-oriented digital design project if you are precise about where hardware helps.

### 10.2 Begin without collecting live posts

Run `python -m src.05_signal_demo --mode baseline`, then `python -m src.05_signal_demo --mode roundtrip`. Compare `results/signals_baseline.json` and `results/signals_roundtrip.json`. Run `python -m src.07_evaluate_signals --mode baseline` and `--mode roundtrip` to calculate coverage, accuracy, macro-F1 and median generation latency. Optionally use `--mode hf_quantized` if its backend is installed. The five samples are a software smoke test, not a statistically meaningful dataset. The script reads five **synthetic** financial posts from `data/synthetic_posts.csv`. The LLM receives an instruction to emit one of `POSITIVE`, `NEGATIVE` or `NEUTRAL`; if its text does not match one of those labels, the script returns `ABSTAIN` rather than silently inventing a label. Results are saved to mode-specific JSON files. These are sentiment proxies, **not** buy/sell orders.

For a real event dataset, define a schema including:

`event_id, post_id, author_id, text, event_time_utc, ingest_time_utc, symbol, source, dedupe_hash, label, label_confidence`.

Use only posts from a source and time window you have lawful access to. The X API has changing commercial access rules; consult official developer documentation before planning your data source. Never store API credentials in the repository, and do not scrape around access restrictions. Separate **a post's published timestamp** from the timestamp at which your system could first observe it.

### 10.3 Which task should the model perform?

Avoid asking the LLM “Should we buy this stock?” at first. Split the task into measurable subtasks:

1. **Ticker extraction:** which company or symbol is mentioned, and is it ambiguous?
2. **Event relevance:** is it material company news, market-wide commentary, joking, or a rumor?
3. **Event type:** earnings surprise, guidance revision, product recall, acquisition, regulatory update, or none.
4. **Direction:** positive, negative or neutral **information sentiment**, not predicted return.
5. **Confidence/abstention:** does the text have enough reliable information to classify at all?

Build a labeled dataset with a written annotation rubric, two reviewers for a subset and a reconciliation process. Start with 100-200 well-balanced synthetic or properly licensed historical items; only then expand to a larger historical corpus. Split chronologically into training/development/test periods, and prevent duplicate posts and follow-ups about the same event from leaking across splits.

### 10.4 Build useful non-LLM baselines

A rule-based keyword classifier is cheap and fast but brittle. A small transformer encoder fine-tuned for financial sentiment (for example FinBERT, subject to its model-weight license) is another legitimate baseline. A compact generative LLM should be tested for whether its additional latency improves event extraction or context reasoning. The strongest paper may find that the LLM is **less** suitable than a smaller classification model for the latency budget.

### 10.5 Paper signal pipeline

`historical post -> deduplicate -> ticker/entity check -> label and confidence -> score threshold -> timestamped signal -> hypothetical execution model -> historical evaluation`.

Start with simple signals: `signal = +1` for positive, `-1` for negative, and `0` for neutral/abstain. This is just a scoring rule. Do not interpret sentiment alone as a validated trading edge. Evaluate precision/recall/F1 before even attempting a returns backtest.

If you add prices, your market-data sample at decision time must be **after** `ingest_time_utc + measured_processing_latency` and after any assumed order delay. Include transaction fees, spread, market impact, survivorship bias, trading halts and missing data. Report a realistic no-trade/abstention rate. Use walk-forward evaluation and keep hyperparameter selection out of the held-out test set. A backtest that uses prices that occurred before the message was observable is invalid due to look-ahead bias.

### 10.6 Final application comparison

Run the *same* labeled events through (a) full-precision LLM, (b) software round-trip codec, (c) genuine compressed cache, and (d) FPGA-backed mode **only if that mode has been integrated**. Measure label agreement, F1, abstentions, total latency and resource utilization. If you cannot connect the FPGA codec to inference before the final presentation, demonstrate model quality and an independent FPGA trace accelerator as **two honest, linked parts** rather than claiming nonexistent end-to-end acceleration.

# Part VI. Advanced projects and final submission

## Lab 11 - Stretch goals: connect compression with attention

Choose **one** stretch goal, not all of them:

**Option A: KIVI-inspired hybrid scaling.** Published work finds differences in how keys vs values should be quantized: channel-based key groups and token-based value groups. Implement an explicit transform/packing layout in Python and RTL, including outlier handling or a high-precision residual block. Quantization must still be verified on the **actual model and workload**, not just asserted from a paper.

**Option B: FPGA dynamic scale engine.** Add reduction trees for min/max or max-absolute value, integer reciprocal/LUT, rounding, scale metadata output, and a decompressor. Use randomized RTL test vectors and report DSP and Fmax vs fixed-scale core.

**Option C: Real host-to-FPGA integration.** Use DMA/PCIe or a suitably fast board interface, implement buffer ownership, batch/overlap strategy and measured transfer overhead. Avoid UART as the presumed high-throughput production link. Connect to a *working* custom compressed-resident host cache interface only if you can prove correctness and report end-to-end numbers.

**Option D: Compressed-domain attention.** Instead of decompressing to the original FP16 tensor and reloading it, experiment with dequantization fused into attention or quantized dot products. This is a substantially harder project but offers a more plausible end-to-end bandwidth reduction. Start with one attention head and compare to a NumPy reference.

### Research context

- **KIVI** (ICML 2024) studies 2-bit asymmetric KV quantization, uses different key/value grouping, and demonstrates that cache choices change both memory and output behavior.
- **KVQuant** (NeurIPS 2024) adds per-channel keys, non-uniform quantization and outlier management, illustrating why a naive low-bit codec may hurt accuracy.
- **Hugging Face cache documentation** supplies software interfaces and a genuine quantized-cache baseline, but its algorithms and supported backends may differ by version.

These are useful **design references**, not instructions to claim you have reproduced published accuracy, peak memory or throughput numbers on a completely different FPGA and model.

## Final live demo, report and grading rubric

Your live presentation should execute, in order: **(1)** Python codec unit tests, **(2)** model cache extraction/shape display, **(3)** one baseline/roundtrip generated answer comparison, **(4)** FPGA RTL self-check pass, **(5)** if hardware exists, a verified board-loopback result, **(6)** the precomputed benchmark table and plots, and **(7)** synthetic financial post to classification demo. Prepare offline screenshots in case the model download or board connection fails during presentation.

### Deliverables

| Item | Minimum content |
|:--|:--|
| Repository | README, dependency/version lock, software and RTL source, deterministic test scripts |
| Design report | motivation, theory, memory formula, codec math, stream diagram, scaling and metadata format |
| Verification | unit test pass, waveform screenshots, randomized RTL scoreboard, hardware byte comparison if available |
| Synthesis | exact FPGA, Vivado version, clock constraint, LUT/FF/BRAM/DSP/WNS, Fmax if supported |
| Benchmarks | raw data CSV, exact device/model/prompt versions, median/range, memory byte accounting |
| Accuracy | held-out prompts, quantization error and generation/label metrics |
| Finance demo | historical/synthetic source, labels, results, caveats, no live trading |
| Reflection | what worked, what did not, system bottleneck, clear next experiment |

### Self-grading guide (100 points)

- **20 pts theory & reproducibility:** every teammate understands attention/GQA; setup and exact versions documented.
- **20 pts algorithm & quality:** mathematically consistent codec, packing, metadata, tests, measured error and generation impact.
- **25 pts FPGA correctness:** ready/valid protocol, scoreboard, stall/reset tests, synthesis/timing, board loopback if available.
- **20 pts fair benchmarking:** clearly separated groups A-F, precision/bandwidth/resource/quality measurements, no misleading speedup.
- **10 pts application:** labeled offline classifier, latency and baselines, anti-leakage/time alignment.
- **5 pts communication:** readable architecture diagram, clean repository, understandable final video or live demo.

### Two versions of success

**Minimum successful project:** You show that a true LLM produces real K/V arrays, that your software codec compresses them with quantified error, and that **verified FPGA RTL** performs a documented compatible integer quantization/packing operation on those traces. Your report distinguishes this from a compressed-resident model or speedup claim.

**Excellent full-integration project:** You add a custom compressed-resident cache, transport to/from FPGA, support metadata and decompression, verify model output against the software oracle, and show reproducible end-to-end latency and memory changes, even if transfer overhead makes the FPGA version slower. A measured negative result with a correct explanation can be a strong research outcome.

# Appendix A. Answers, debugging and glossary

### Lab 1 self-check answers

**Why no cached Q?** The next decode step computes a new query for the current token; past queries are generally not needed to compare this new token against prior K/V. **Why layers?** Every layer has distinct learned transformations, yielding its own K and V. **Why can INT4 change output?** Approximation changes K dot products, softmax weights and V mixtures; resulting logits can change the next token. **Why short-context slowdown?** Quant/dequant processing and format conversions can cost more than the bandwidth savings.

### Worked memory problem

Assume `B=2`, `L=24`, `H_KV=2`, `T=4096`, `D=64` and FP16. Total = `2*2*24*2*4096*64*2` bytes = 100,663,296 bytes = **96 MiB**. With our format, there are `B*L*H_KV*T*2` K+V vectors, each of 34 bytes, so total compressed representation = `2*24*2*4096*2*34` bytes = 26,738,688 bytes = **25.5 MiB**. Ratio = 96/25.5 = 3.7647x. This does not include hot residual copies or GPU allocation overhead.

### Worked fixed-scale RTL example

Fixed Q8.8 scale = 32 integer LSB per INT4 code. Inputs `[0,32,-32,256,-256,224,-16,16]` give q codes `[0,1,-1,7,-8,7,-1,1]`. Low-nibble-first packing gives `[0x10,0x7F,0x78,0x1F]`. `x_int=-16` is exactly halfway between 0 and -1; the RTL's *away-from-zero* rule maps it to -1. The Python dynamic-scale reference uses **a different scale and tie rule**. Make the rules match before connecting software and RTL.

### Common mistakes and immediate fixes

| Symptom | Likely cause | Verify |
|:--|:--|:--|
| Cache memory does not shrink | compress then immediately decompress into a `DynamicCache` | inspect true storage bytes, not hypothetical ratio |
| INT4 output differs | scale mismatch, tie rounding, nibble order, overflow | compare exact fixed-point oracle per scalar |
| Negative bytes look wrong | unsigned vs signed nibble interpretation | apply two's complement and sign extension |
| Different outputs at small bit-width | numerical distortion changes attention | log per-layer error and logits |
| Quantized cache slower | conversion work / short context / memory not bottleneck | benchmark long contexts and decode separately |
| FPGA `m_data` changes during stall | ready/valid bug | assert stable data while `m_valid && !m_ready` |
| Vivado report shows no meaningful clock | XDC clock missing | create clock and inspect WNS |
| GPU memory “compression” barely changes | weights dominate at short prompt | compute analytic KV bytes and isolate allocator contribution |
| LLM financial labels are inconsistent | unconstrained output and ambiguous event | rigid schema, abstain, annotated data |
| Apparent trading profits vanish | look-ahead leakage, costs, event timestamp problems | timestamp all inputs/outputs and simulate realistic delays |

### Glossary

**Attention:** data-dependent weighted combination of token values. **Autoregressive:** generates each next token conditioned on prior ones. **Batch:** multiple sequences processed together. **Causal mask:** prevents attention to future tokens. **Decode:** incremental generation after the initial prompt. **Embedding:** learned numeric vector for a token. **GQA:** grouped-query attention, with fewer KV than query heads. **Head dimension:** number of scalar entries in each head vector. **INT4:** signed four-bit numeric representation; packing puts two entries in one byte. **KV cache:** stored keys/values from earlier tokens for each layer. **Logits:** unnormalized scores of next-token possibilities. **Metadata:** scale/zero point/shape/frame information required to interpret compressed bytes. **Prefill:** first transformer pass through a prompt. **Quantization:** approximate mapping of higher-precision numbers into a smaller code set. **RoPE:** position-dependent rotation applied to queries/keys. **Softmax:** converts logits/scores to positive normalized weights. **Token:** integer-coded text fragment. **TTFT:** time to first generated token. **WNS:** worst negative slack in FPGA timing analysis.

# Appendix B. Primary references

1. Hugging Face, [How caching works](https://huggingface.co/docs/transformers/en/cache_explanation). Transformer attention, KV layouts and decode behavior.
2. Hugging Face, [Cache strategies](https://huggingface.co/docs/transformers/en/kv_cache). Dynamic, static and quantized cache backends and latency tradeoffs.
3. Qwen, [Qwen2.5-0.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct). Model license/configuration and test weights.
4. Liu et al., [KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache](https://proceedings.mlr.press/v235/liu24bz.html), ICML 2024.
5. Hooper et al., [KVQuant: Towards 10 Million Context Length LLM Inference with KV Cache Quantization](https://proceedings.nips.cc/paper_files/paper/2024/hash/028fcbcf85435d39a40c4d61b42c99a4-Abstract-Conference.html), NeurIPS 2024.
6. AMD, [AXI4-Stream interface handshake](https://docs.amd.com/r/en-US/pg256-sdfec-integrated-block/AXI4-Stream-Interface). Ready/valid semantics.
7. PyTorch, [Get started](https://pytorch.org/get-started/locally/). Installation and CUDA compatibility.
8. [ProsusAI FinBERT](https://huggingface.co/ProsusAI/finbert). Financial sentiment encoder; verify model-weight license before using it.

**Reproducibility note:** This manual is a starting implementation and a planned hardware development sequence, **not** a claim that the board or downloadable model were run in this author's environment. The Python codec, fixed-scale Python oracle and their ten unit tests were executed successfully before publication. The Vivado simulation and full Hugging Face model benchmarking must be run and recorded on your team's machines.
